/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
//

/**
 *
 * @author Rini
 */
public class c_Beranda extends CLass_Musik.Musik {

    private View.Siffing_Home_Aplikasi the_v;

    public c_Beranda() {
        the_v = new View.Siffing_Home_Aplikasi();
        the_v.setVisible(true);
        the_v.tombolLogin(new LoginListener());
        the_v.tombolRegister(new registerListener());
        the_v.tombolKeluar(new keluarListenenr());
        the_v.tombolAbout(new aboutListner());
    }

    private class aboutListner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_About();
            the_v.dispose();
        }

    }

    private class LoginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new C_Login_Pegawai();
            } catch (SQLException ex) {
                Logger.getLogger(c_Beranda.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class registerListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Register();
            } catch (SQLException ex) {
                Logger.getLogger(c_Beranda.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class keluarListenenr implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane pane = new JOptionPane("Anda Yakin akan keluar");
            soundTombol();
            Object[] options = new String[]{"YES", "NO"};
            pane.setOptions(options);
            JDialog dialog = pane.createDialog(new JFrame(), "Message");
            dialog.show();
            Object obj = pane.getValue();
            soundTombol();
            if (obj.equals("YES")) {
                try {
                    Thread.sleep(1000);
                } catch (Exception fer) {
                }
                System.exit(0);
            } else {

            }
        }
    }

}
