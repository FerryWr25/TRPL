/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class Distribusi extends Model_Master {

    ResultSet rs;
    private String ID_Jabatan;
    private String Keahlian;
    private String Keterbatasan;
    private String Alasan;
    private String Total;
    private String Bulan;
    private String catatanku;
    private String NamaToko[];

    public Distribusi() throws SQLException {
        super();

    }

    //ambil catatan untuk sales
    public String getCatatanku(String username) throws SQLException {
        String query = "select Catatan from pegawai where Username ='" + username + "' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                catatanku = rs.getString("Catatan");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return catatanku;
    }

    public DefaultTableModel getData_Beban() throws SQLException {
        String kolom[] = {"Periode", "Jumlah_Distribusi", "Minimal_Distribusi", "Awal_Beban", "Akhir_Beban"};
        String query = "select * from beban_distribusi";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public boolean insertDataDistribusi(String query1, String query2, String Data[]) throws SQLException {
        String query = "INSERT INTO `distribusi` (`ID_Distribusi`, `ID_Toko`, `ID_Pegawai`, `Tanggal_Distribusi`, "
                + "`Jumlah_Pengiriman`, `Harga`, `Discount`, `Total_Harga` ,`ID_Beban_Distribusi`,`Status_Distribusi`)"
                + " VALUES (NULL, " + query1 + ", " + query2 + ", '" + Data[2] + "', " + Data[3] + "," + Data[4] + ", " + Data[5] + ","
                + (Integer.parseInt(Data[4]) - (Integer.parseInt(Data[4]) * Integer.parseInt(Data[5]) / 100))
                + "," + Data[7] + ", 'Belum diverifikasi');";
        System.out.println(Data[4]);
        System.out.println(Data[5]);
        System.out.println("hasil discount" + Integer.parseInt(Data[4]) * (Integer.parseInt(Data[5]) / 100));
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean insertDataBeban(String Data[], String sisa_Semen) throws SQLException {
        String query = "INSERT INTO `beban_distribusi`(`ID_Beban_Distribusi`, `Jumlah_Distribusi`, `JmlMininal_PenjualanSales`, `Tanggal_AwalBeban`, `Tanggal_AkhirBeban`, `Sisa_Semen`)"
                + " VALUES (NULL," + Data[1] + "," + Data[2] + ",'" + Data[3] + "','" + Data[4] + "'," + sisa_Semen + ")";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public DefaultTableModel getData_LaporanDistribusi() throws SQLException {
        String kolom[] = {"Bulan", "Jml_Pengiriman", "Total_Distribusi"};
        String query = "select \n"
                + "Substring(d.Tanggal_Distribusi,3,4) , \n"
                + "count(d.ID_Distribusi), SUM(d.Jumlah_Pengiriman)\n"
                + "from distribusi d join pegawai p \n"
                + "on(p.ID_Pegawai=d.ID_Pegawai) \n"
                + "group by Substring(d.Tanggal_Distribusi,3,4)";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public String getPeriode_Angka() throws SQLException {
        String query = "select ID_Beban_Distribusi from beban_distribusi order by ID_Beban_Distribusi desc limit 1";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Beban_Distribusi");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getDATA_Periode(int periode) throws SQLException {
        String query = "SELECT Jumlah_Distribusi from beban_distribusi where ID_Beban_Distribusi = " + periode;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Jumlah_Distribusi");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getPekerja() throws SQLException {
        String query = "select COUNT(*) from pegawai where ID_Jabatan not BETWEEN 1 and 2";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("COUNT(*)");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }
///input distribusi ambil nama-nama dan data

    public String[] getNamaToko() throws SQLException {
        String query = "select NamaToko from toko order by ID_Toko asc";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        String NamaTokoNya[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        NamaTokoNya = new String[hitung];
        int i = 0;
        while (hasil.next()) {
            NamaTokoNya[i] = hasil.getString(1);
            i++;
        }
        return NamaTokoNya;
    }

    public String[] ID_BEban() throws SQLException {
        String query = "select ID_Beban_Distribusi from beban_distribusi ORDER BY ID_Beban_Distribusi desc limit 3 ";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        String ID[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        ID = new String[hitung];
        int i = 0;
        while (hasil.next()) {
            ID[i] = hasil.getString(1);
            i++;
        }
        return ID;
    }

    public String getIDTOKO(String namaToko) throws SQLException {
        String query = "select ID_Toko from toko where NamaToko like '%" + namaToko + "%'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Toko");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getIDPegawai(String namaSales) throws SQLException {
        String query = "select ID_Pegawai from pegawai where Nama_Pegawai like '%" + namaSales + "%'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Pegawai");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String[] getNamaSales() throws SQLException {
        String query = "select Nama_Pegawai from pegawai where ID_Pegawai > 3";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        String NamaSales[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        NamaSales = new String[hitung];
        int i = 0;
        while (hasil.next()) {
            NamaSales[i] = hasil.getString(1);
            i++;
        }
        return NamaSales;
    }

    public DefaultTableModel getKaryawan_GagaLDistribusi() throws SQLException {
        String kolom[] = {"Nomer", "Nama", "Alamat", "Jenis Kelamin", "Gagal Memenuhi target", "Catatan"};
        String query = "select ID_Pegawai, Nama_Pegawai,Alamat, Jenis_kelamin ,Jumlah_Punisment ,"
                + "Catatan from pegawai where Jumlah_Punisment > 0 order by Jumlah_Punisment desc ";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    ///insert catatan buat karyawan
    public boolean insertCatatan(String Catatan, String Id) throws SQLException {
        String query = "UPDATE `pegawai` SET `Catatan` = '" + Catatan + "'"
                + " WHERE `pegawai`.`ID_Pegawai` = " + Id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public String getPunismentKaryawan(int id) throws SQLException {
        String query = "select Jumlah_Punisment from pegawai where ID_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Jumlah_Punisment");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    ////riwayat distribusi sales
    public DefaultTableModel getRiwayat_GagaLDistribusi(String id) throws SQLException {
        String kolom[] = {"Periode Beban", "Jumlah Distribusi", "Nama Toko", "Status"};
        String query = "select d.ID_Beban_Distribusi, SUM(d.Jumlah_Pengiriman), t.NamaToko ,d.Status_Distribusi from distribusi d join "
                + "toko t on (d.ID_Toko=t.ID_Toko) join pegawai p on (d.ID_Pegawai=p.ID_Pegawai) "
                + "where p.ID_Pegawai = " + id + " group by ID_Distribusi";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public String getIdKaryawan(String username) throws SQLException {
        String query = "select ID_Pegawai from pegawai where Username = '" + username + "'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Pegawai");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getPeriode() throws SQLException {
        String query = "select MAX(ID_Beban_Distribusi) from beban_distribusi";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("MAX(ID_Beban_Distribusi)");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getBEban_Periode(String periode) throws SQLException {
        String query = "select JmlMininal_PenjualanSales from beban_distribusi where ID_Beban_Distribusi = " + periode;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("JmlMininal_PenjualanSales");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getTotalDistribusi(String id) throws SQLException {
        String query = "select SUM(Jumlah_Pengiriman) from distribusi where ID_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("SUM(Jumlah_Pengiriman)");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getTotalTotalToko(String id) throws SQLException {
        String query = "select COUNT(ID_Toko) from distribusi where ID_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("COUNT(ID_Toko)");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public DefaultTableModel getRiwayat_Pencarian(String cari, String id) throws SQLException {
        String kolom[] = {"Periode Beban", "Jumlah Distribusi", "Nama Toko", "Status"};
        String query = "select d.ID_Beban_Distribusi, SUM(d.Jumlah_Pengiriman), t.NamaToko ,d.Status_Distribusi from distribusi d "
                + "join toko t on (d.ID_Toko=t.ID_Toko) join pegawai p on (d.ID_Pegawai=p.ID_Pegawai) where (p.ID_Pegawai = " + id + ") "
                + "and ((t.NamaToko like '%" + cari + "%') or "
                + "(Status_Distribusi like '%" + cari + "%')) group by ID_Distribusi";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public DefaultTableModel getTotalDistribusi_Sales(String username) throws SQLException {
        String kolom[] = {"Nomer Beban", "Total Pengiriman", "Status Distribusi"};
        String query = "select d.ID_Beban_Distribusi,SUM(d.Jumlah_Pengiriman) ,d.Status_Distribusi from distribusi d join pegawai "
                + "p on (d.ID_Pegawai=p.ID_Pegawai) "
                + "where p.Username = '" + username + "' group by d.ID_Pegawai, d.Status_Distribusi ";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }
//total distribusi berdasarkan id bebsannya

    public String getTotalPengiriman() throws SQLException {
        String query = "select SUM(Jumlah_Pengiriman) from distribusi where Status_Distribusi = 'Verifikasi'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("SUM(Jumlah_Pengiriman)");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getTotalPengadaan() throws SQLException {
        String query = "select SUM(Jumlah_Distribusi) from beban_distribusi";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("SUM(Jumlah_Distribusi)");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getSisaSemen() throws SQLException {
        String query = "select SUM(Sisa_Semen) from beban_distribusi";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("SUM(Sisa_Semen)");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    ///ambil id beban terakhir
    public String getLast_IDBEban() throws SQLException {
        String query = "select ID_Beban_Distribusi from beban_distribusi order by ID_Beban_Distribusi desc LIMIT 1";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Beban_Distribusi");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }
//    mengenai validasi distribusi

    public DefaultTableModel getDistibusi_BelumVRFSI() throws SQLException {
        String kolom[] = {"No", "Nama", "Tanggal", "Pengiriman", "Total Harga", "Nomer Beban", "Status"};
        String query = "select  d.ID_Distribusi, p.Nama_Pegawai ,d.Tanggal_Distribusi,d.Jumlah_Pengiriman,d.Total_Harga,d.ID_Beban_Distribusi,Status_Distribusi "
                + "from distribusi d join pegawai p on (p.ID_Pegawai=d.ID_Pegawai)";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public boolean insertDataValidasi(String Data, String id) {
        String query = "UPDATE `distribusi` SET `Status_Distribusi` = '" + Data + "' WHERE `ID_Distribusi` = " + id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }

//    bahan grafik
    public int[] getSisa_Semen() throws SQLException {
        String query = "select Sisa_Semen from beban_distribusi ORDER BY ID_Beban_Distribusi ASC";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Sisa[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Sisa = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Sisa[i] = hasil.getInt(1);
            i++;
        }
        return Sisa;
    }

    public int[] getMInimal() throws SQLException {
        String query = "select JmlMininal_PenjualanSales from beban_distribusi ORDER BY ID_Beban_Distribusi asc";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Minimal[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Minimal = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Minimal[i] = hasil.getInt(1);
            i++;
        }
        return Minimal;
    }

    public int[] getDistribusi_Grafik() throws SQLException {
        String query = "select Jumlah_Distribusi from beban_distribusi ORDER BY ID_Beban_Distribusi asc";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Beban[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Beban = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Beban[i] = hasil.getInt(1);
            i++;
        }
        return Beban;
    }

    public int[] getID_Distribusi() throws SQLException {
        String query = "select ID_Beban_Distribusi from beban_distribusi ORDER BY ID_Beban_Distribusi asc";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Beban[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Beban = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Beban[i] = hasil.getInt(1);
            i++;
        }
        return Beban;
    }
//kelola toko 

    public DefaultTableModel getDataToko() throws SQLException {
        String kolom[] = {"No", "Nama Toko", "Pemilik", "Alamat", "No Telp"};
        String query = "SELECT * FROM `toko`";
        System.out.println(query);
        return getDataTabel(kolom, query);
    }

    public String[] getDataToko_To_Field(String id) throws SQLException {
        String query = "select NamaToko,Nama_Pemilik,Alamat,No_Telp from toko where ID_Toko = " + id;
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        String Beban[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Beban = new String[hitung];
        int i = 0;
        while (hasil.next()) {
            Beban[i] = hasil.getString(1);
            i++;
        }
        return Beban;
    }

    public String[] getTOKO_WithID(String ID) throws SQLException {
        String data[] = new String[4];
        String Query = "select NamaToko , Nama_Pemilik  , Alamat , No_Telp from toko where ID_Toko =" + ID + ";";
        return getData_ID(Query, data);
    }

    public boolean updateToko(String Data[], String id) {
        String query = "UPDATE `toko` SET `NamaToko`= '" + Data[0] + "',"
                + "`Nama_Pemilik`= '" + Data[1] + "',`Alamat`= '" + Data[2] + "',`No_Telp`= '" + Data[3] + "' WHERE ID_Toko = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean insertToko(String Data[]) {
        String query = "INSERT INTO `toko`(`ID_Toko`, `NamaToko`, `Nama_Pemilik`, `Alamat`, `No_Telp`) VALUES"
                + " (NULL,'" + Data[0] + "','" + Data[1] + "','" + Data[2] + "','" + Data[3] + "')";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean DeleteToko(String id) {
        String query = "DELETE FROM `toko` WHERE ID_Toko = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }
}
