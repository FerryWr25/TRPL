/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Distribusi;
import View.Kelola_List_Toko;
import View.Sifings_Login;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class c_kelola_Toko extends CLass_Musik.Musik {

    private View.Kelola_List_Toko the_V;
    private View.Sifings_Login the_V2;
    private Model.Distribusi the_M;
    private String username;

    public c_kelola_Toko(String username) throws SQLException {
        the_V = new Kelola_List_Toko();
        the_V2 = new Sifings_Login();
        the_M = new Distribusi();
        the_V.setVisible(true);
        this.username = username;
        the_V.setTable_TOKO(the_M.getDataToko());
        the_V.edit().addActionListener(new updateListener());
        the_V.cancel().addActionListener(new cancelListener());
        editebleField(false);
        the_V.tambahBaru().addActionListener(new tambahListener());
        the_V.hapus().addActionListener(new deleteListener());
        the_V.kembali().addActionListener(new kembaliListener());
    }

    private void editebleField(boolean status) {
        if (status == false) {
            the_V.setEditFieldNama(false);
            the_V.setEditFieldNamaToko(false);
            the_V.setEditField_Alamat(false);
            the_V.setEditField_NOTelp(false);
        } else {
            the_V.setEditFieldNama(true);
            the_V.setEditFieldNamaToko(true);
            the_V.setEditField_Alamat(true);
            the_V.setEditField_NOTelp(true);
        }
    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (the_V.getButtonUpdate().equalsIgnoreCase("Edit")) {
                editebleField(true);
                if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                    the_V.tampilPesan("Silahkan pilih tabel terlebih dahulu");
                } else {
                    try {
                        String[] data = the_M.getTOKO_WithID(the_V.GetTable());
                        the_V.setNamaToko(data[0]);
                        the_V.setNamaPemilik(data[1]);
                        the_V.setAlamat(data[2]);
                        the_V.setNO_Telp(data[3]);
                        the_V.setButtonUpdate(" Simpan");
                        the_V.setButtonTambah(false);
                        the_V.setButtonHapus(false);
                    } catch (SQLException ex) {
                        Logger.getLogger(c_kelola_Toko.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } else {
                if (the_M.updateToko(the_V.getDataToko(), the_V.GetTable())) {
                    the_V.tampilPesan("Data berhasil diperbarui");
                    the_V.setNamaToko("");
                    the_V.setNamaPemilik("");
                    the_V.setAlamat("");
                    the_V.setNO_Telp("");
                    the_V.setButtonUpdate("Edit");
                     the_V.setButtonTambah(true);
                     the_V.setButtonHapus(true);
                    try {
                        the_V.setTable_TOKO(the_M.getDataToko());
                    } catch (SQLException ex) {
                        Logger.getLogger(c_kelola_Toko.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    the_V.tampilPesan("GAGAL Update data");
                }
            }

        }

    }

    public void cancelNya() {
        the_V.setNamaToko("");
        the_V.setButtonTambah("Tambah Baru+");
        the_V.setNamaPemilik("");
        the_V.setAlamat("");
        the_V.setNO_Telp("");
        the_V.setButtonUpdate("Edit");
        editebleField(false);
        the_V.setButtonTambah(true);
        the_V.setButtonEDIt(true);
        the_V.setButtonHapus(true);
    }

    private class cancelListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setNamaToko("");
            the_V.setButtonTambah("Tambah Baru+");
            the_V.setNamaPemilik("");
            the_V.setAlamat("");
            the_V.setNO_Telp("");
            the_V.setButtonUpdate("Edit");
            editebleField(false);
            the_V.setButtonTambah(true);
            the_V.setButtonEDIt(true);
            the_V.setButtonHapus(true);
        }
    }

    private class tambahListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (the_V.getButtonTambah().equalsIgnoreCase("Tambah Baru+")) {
                editebleField(true);
                the_V.setButtonTambah("Simpan");
                the_V.setNamaToko("");
                the_V.setNamaPemilik("");
                the_V.setAlamat("");
                the_V.setNO_Telp("");
                the_V.setButtonEDIt(false);
                the_V.setButtonHapus(false);
            } else {
                if (the_V.getNamaToko().isEmpty()) {
                    the_V.tampilPesan("Nama tidak boleh kosong");
                } else if (the_V.getNamaPemilik().isEmpty()) {
                    the_V.tampilPesan("Nama pemilik tidak boleh kosong");
                } else if (the_V.getAlamat().isEmpty()) {
                    the_V.tampilPesan("Alamat tidak boleh kosong");
                } else if (the_V.getNO_Telp().isEmpty()) {
                    the_V.tampilPesan("No_Telp tidak boleh kosong");
                } else {
                    the_M.insertToko(the_V.getDataToko());
                    the_V.tampilPesan("Sukses Insert");
                    the_V.setButtonTambah(" Tambah Baru+");
                    cancelNya();
                    try {
                        the_V.setTable_TOKO(the_M.getDataToko());
                    } catch (SQLException ex) {
                        Logger.getLogger(c_kelola_Toko.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }

        }

    }

    private class deleteListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                the_V.tampilPesan("Silahkan pilih baris yang akan dihapus");
            } else {
                String[] data = null;
                try {
                    data = the_M.getTOKO_WithID(the_V.GetTable());
                } catch (SQLException ex) {
                    Logger.getLogger(c_kelola_Toko.class.getName()).log(Level.SEVERE, null, ex);
                }
                the_V.setNamaToko(data[0]);
                JOptionPane pane = null;
                pane = new JOptionPane("            Anda Yakin ingin Menghapus \n                   Toko " + "' " + (data[0]) + " '");
                Object[] options = new String[]{"YES", "NO"};
                soundTombol();
                pane.setOptions(options);
                JDialog dialog = pane.createDialog(new JFrame(), "Message");
                dialog.show();
                Object obj = pane.getValue();
                if (obj.equals("YES")) {
                    the_M.DeleteToko(the_V.GetTable());
                    try {
                        the_V.setTable_TOKO(the_M.getDataToko());
                    } catch (SQLException ex) {
                        Logger.getLogger(c_kelola_Toko.class.getName()).log(Level.SEVERE, null, ex);
                    }
                } else {
                    cancelListener fer = new cancelListener();
                }

            }
        }
    }

    private class kembaliListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_Direktur(username);
            the_V.dispose();
        }

    }
}
