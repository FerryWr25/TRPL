/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class c_Toko extends CLass_Musik.Musik{

    private View.Toko the_V;
    private Model.Pegawai the_M;
    private View.Sifings_Login the_V2;
    private String username;

    public c_Toko(String username) throws SQLException {
        the_V = new View.Toko();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Pegawai();
        the_V.setVisible(true);
        the_V.tombolAdd_Toko(new AddToko_Listener());
        the_V.tombolHome(new home_Listner());
    }

    private class AddToko_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (the_M.insertDataToko(the_V.getDataToko())) {
                the_V.tampilPesan("Tambah Toko Berhasil Dimasukkan");
            } else {
                the_V.tampilPesan("Tambah toko GAGAl");
            }
            new c_Direktur(username);
        }

    }

    private class home_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Direktur(username);
            the_V.dispose();
        }

    }

}
