package View;

import java.awt.event.ActionListener;

public class Siffing_Home_Aplikasi extends javax.swing.JFrame {

    public Siffing_Home_Aplikasi() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    public void tombolLogin(ActionListener action) {
        this.loginButton.addActionListener(action);
    }

    public void tombolRegister(ActionListener action) {
        this.tombolRegister.addActionListener(action);
    }

    public void tombolKeluar(ActionListener action) {
        this.tombolKeluar.addActionListener(action);
    }

    public void tombolAbout(ActionListener action) {
        this.aboutButton.addActionListener(action);
    }

    public void tombol_About(ActionListener action) {
        this.aboutButton.addActionListener(action);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        aboutButton = new javax.swing.JButton();
        tombolRegister = new javax.swing.JButton();
        loginButton = new javax.swing.JButton();
        tombolKeluar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        aboutButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button About_1.png"))); // NOI18N
        aboutButton.setBorderPainted(false);
        aboutButton.setContentAreaFilled(false);
        aboutButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        aboutButton.setDefaultCapable(false);
        aboutButton.setFocusPainted(false);
        aboutButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button About 2_1.png"))); // NOI18N
        getContentPane().add(aboutButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 80, 140, 80));

        tombolRegister.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Buttom Register 1.png"))); // NOI18N
        tombolRegister.setBorderPainted(false);
        tombolRegister.setContentAreaFilled(false);
        tombolRegister.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tombolRegister.setDefaultCapable(false);
        tombolRegister.setFocusPainted(false);
        tombolRegister.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Buttom Register 2.png"))); // NOI18N
        getContentPane().add(tombolRegister, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 90, 140, 60));

        loginButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Buttom LogIn 1.png"))); // NOI18N
        loginButton.setBorderPainted(false);
        loginButton.setContentAreaFilled(false);
        loginButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        loginButton.setDefaultCapable(false);
        loginButton.setFocusPainted(false);
        loginButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Buttom LogIn 2.png"))); // NOI18N
        getContentPane().add(loginButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 90, 130, 60));

        tombolKeluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Buttom Quit 1.png"))); // NOI18N
        tombolKeluar.setBorderPainted(false);
        tombolKeluar.setContentAreaFilled(false);
        tombolKeluar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        tombolKeluar.setFocusPainted(false);
        tombolKeluar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Buttom Quit 2.png"))); // NOI18N
        getContentPane().add(tombolKeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 90, 130, 60));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Beranda Atas.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 150));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Beranda Bawah.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 650, 1280, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Home-Aktor.gif"))); // NOI18N
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 1280, 510));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Siffing_Home_Aplikasi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton aboutButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton loginButton;
    private javax.swing.JButton tombolKeluar;
    private javax.swing.JButton tombolRegister;
    // End of variables declaration//GEN-END:variables
}
