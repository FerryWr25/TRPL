/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Pendaftar_Lolos extends javax.swing.JFrame {

    public Pendaftar_Lolos() {
        initComponents();
        this.setLocationRelativeTo(this);
    }

    public void tampilPesan(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public int tampilPeringatan(String pesan) {
        return JOptionPane.showConfirmDialog(this, pesan, null, JOptionPane.YES_NO_OPTION);
    }

    public void setFieldBatas(String text) {
        this.field_batas.setText(text);
    }

    public void setTablePendatar_lolos(DefaultTableModel table) {
        this.setPendaftar_Lolos.setModel(table);
    }

    public String getBatas() {
        return field_batas.getText();
    }

    public void buttonBatas(ActionListener action) {
        this.buttonBatas.addActionListener(action);
    }

    public void buttonBackHome(ActionListener action) {
        this.tombolBack.addActionListener(action);
    }

    public void buttonUmumkan(ActionListener action) {
        this.umumkanButton.addActionListener(action);
    }

    public void buttonShowAll(ActionListener action) {
        this.showAll.addActionListener(action);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        showAll = new javax.swing.JButton();
        umumkanButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        setPendaftar_Lolos = new javax.swing.JTable();
        field_batas = new javax.swing.JTextField();
        tombolBack = new javax.swing.JButton();
        buttonBatas = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        showAll.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Show All.png"))); // NOI18N
        showAll.setBorderPainted(false);
        showAll.setContentAreaFilled(false);
        showAll.setFocusPainted(false);
        showAll.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Show All 2.png"))); // NOI18N
        getContentPane().add(showAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 460, 160, 60));

        umumkanButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Terima.png"))); // NOI18N
        umumkanButton.setBorderPainted(false);
        umumkanButton.setContentAreaFilled(false);
        umumkanButton.setFocusPainted(false);
        umumkanButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Terima 2.png"))); // NOI18N
        getContentPane().add(umumkanButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 390, 160, 60));

        setPendaftar_Lolos.setBackground(new java.awt.Color(204, 204, 204));
        setPendaftar_Lolos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        setPendaftar_Lolos.setShowHorizontalLines(false);
        setPendaftar_Lolos.setShowVerticalLines(false);
        jScrollPane1.setViewportView(setPendaftar_Lolos);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 590, 350));
        getContentPane().add(field_batas, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 250, 260, 40));

        tombolBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home.png"))); // NOI18N
        tombolBack.setBorderPainted(false);
        tombolBack.setContentAreaFilled(false);
        tombolBack.setFocusPainted(false);
        tombolBack.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home 2.png"))); // NOI18N
        getContentPane().add(tombolBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 150, 190, 70));

        buttonBatas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Masukkan Jumlah Karyawan.png"))); // NOI18N
        buttonBatas.setBorderPainted(false);
        buttonBatas.setContentAreaFilled(false);
        buttonBatas.setFocusPainted(false);
        buttonBatas.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Masukkan Jumlah Karyawan 2.png"))); // NOI18N
        getContentPane().add(buttonBatas, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 310, 200, 70));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Pendaftar Lolos.png"))); // NOI18N
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        setBounds(0, 0, 1280, 720);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pendaftar_Lolos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pendaftar_Lolos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pendaftar_Lolos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pendaftar_Lolos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pendaftar_Lolos().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonBatas;
    private javax.swing.JTextField field_batas;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable setPendaftar_Lolos;
    private javax.swing.JButton showAll;
    private javax.swing.JButton tombolBack;
    private javax.swing.JButton umumkanButton;
    // End of variables declaration//GEN-END:variables
}
