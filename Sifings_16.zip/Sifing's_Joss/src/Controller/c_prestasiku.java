/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pegawai;
import View.Sifings_Login;
import View.V_Grafikku;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author Rini
 */
public class c_prestasiku extends CLass_Musik.Musik {

    private View.V_Grafikku the_V;
    private View.Sifings_Login the_V2;
    private Model.Pegawai the_M;
    private String username;

    private XYSeriesCollection dataset = new XYSeriesCollection();

    private XYSeries series = new XYSeries("Total Pengiriman Anda");

    public c_prestasiku(String username) throws SQLException {
        the_V = new V_Grafikku();
        the_V2 = new Sifings_Login();
        the_M = new Pegawai();
        the_V.setVisible(true);
        this.username = username;
        the_V.setGajiku("Rp. " + the_M.getGajiku(username));//setGajinya
        the_V.chart(createDataset(the_M.getID_DistribusiKU(username), the_M.getPrestasiKU(username)));
        the_V.setStatus(the_M.getStatus_Gajiku(username));
        the_V.reset();
        the_V.tombalBack().addActionListener(new backHome_Listener());
    }

    public XYDataset createDataset(int Periode[], int jumlahDstribusi[]) {
        series.clear();
        for (int i = 0; i < Periode.length; i++) {
            series.add(Periode[i], jumlahDstribusi[i]);
        }
        dataset.addSeries(series);
        return dataset;
    }
    private class backHome_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_Sales(username);
            the_V.dispose();
        }
        
    }

}
