package sifing.s;

import Controller.c_Beranda;
import Controller.c_Direktur;
import Controller.c_Distribusi;
import Controller.c_Distribusi_HRD;
import Controller.c_Distribusi_Laporan;
import Controller.c_Gaji;
import Controller.c_HRD;
import Controller.c_LaporanDistribusi_Gagal;
import Controller.c_Pendaftar_Karyawan;
import Controller.c_Pengumuman;
import Controller.c_Register;
import Controller.c_Sales;
import Controller.c_Toko;
import Controller.c_ValidasiDIstribusi;
import Controller.c_grafikDIstribusi;
import Controller.c_kelola_Toko;
import Controller.c_perbaruiGaji_HRD;
import Controller.c_prestasiku;
import Controller.c_settingAkun;
import Controller.c_setting_AkunPGW;
import Controller.c_validasiGaji;
import Controller.c_validasiPendaftar;
import java.sql.SQLException;
import java.text.ParseException;

public class SifingS {

    public static void main(String[] args) throws SQLException {
//        
//        try {
//            Thread.sleep(4200);
//        } catch (Exception fer) {
//        }
//        new c_LaporanDistribusi_Gagal();
//        new c_Beranda();
//        new c_Direktur();
//        new c_Sales();
//        new c_HRD();
//        new c_Distribusi();
//        new c_Distribusi_HRD();
//        new c_Register();
//        new c_Distribusi_Laporan();
//        new c_validasiPendaftar();
//        new c_Toko();
//        new c_Pendaftar_Karyawan();
//        new c_Pengumuman();
//        new c_ValidasiDIstribusi("nila");
//        new c_Gaji("nila");
//        new c_settingAkun("nila");
//        new c_validasiGaji("ferry");
//        new c_perbaruiGaji_HRD("ferry");
//        new c_grafikDIstribusi("ferry");
//        new c_prestasiku("stanis");
//        new c_kelola_Toko("ferry");
        new c_setting_AkunPGW("Nila");
    }

}
