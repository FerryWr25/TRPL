package View;

import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Validasi_Pendaftar extends javax.swing.JFrame {

    public Validasi_Pendaftar() {
        initComponents();
    }
    

    public void setTablePendatar(DefaultTableModel table) {
        this.setPendaftar.setModel(table);
    }

    public JLabel setModal() {
        return ModalInput_Nilai;
    }

    public JTextField setInputNilai() {
        return field_Nilai;
    }

    public JButton setSubmit() {
        return submitButton;
    }
    public JButton setCancel() {
        return cancelButton;
    }

    public String getNilai() {
        String nilai = this.field_Nilai.getText();
        return nilai;
    }

    public void tampilPesan(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public int tampilPeringatan(String pesan) {
        return JOptionPane.showConfirmDialog(this, pesan, null, JOptionPane.YES_NO_OPTION);
    }

    public int getSelectedRow() {
        return this.setPendaftar.getSelectedRow();
    }

    public String GetTable() {
        return this.setPendaftar.getValueAt(this.getSelectedRow(), 0).toString();
    }

    public String getNilai_Pendaftar() {
        return this.field_Nilai.getText();
    }

    public void tombolPenilaian(ActionListener action) {
        this.submitButton.addActionListener(action);
    }
    public void tombolCancel(ActionListener action) {
        this.cancelButton.addActionListener(action);
    }

    public void Penilaian(ActionListener action) {
        this.penilaian.addActionListener(action);
    }
    public void backHome(ActionListener action) {
        this.home.addActionListener(action);
    }

    public void setNilai(String text) {
        this.field_Nilai.setText(text);
    }
    public JTable editTable (){
        return setPendaftar;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        field_Nilai = new javax.swing.JTextField();
        cancelButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        ModalInput_Nilai = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        setPendaftar = new javax.swing.JTable();
        penilaian = new javax.swing.JButton();
        home = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(field_Nilai, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 430, 240, 30));

        cancelButton.setText("CANCEL");
        getContentPane().add(cancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 480, 90, 30));

        submitButton.setText("SUBMIT");
        getContentPane().add(submitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 480, 90, 30));

        ModalInput_Nilai.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/PopUp Masukkan Penilaian.png"))); // NOI18N
        getContentPane().add(ModalInput_Nilai, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 350, 340, 210));

        setPendaftar.setBackground(new java.awt.Color(204, 204, 204));
        setPendaftar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        setPendaftar.setSelectionBackground(new java.awt.Color(204, 204, 204));
        setPendaftar.setSelectionForeground(new java.awt.Color(0, 0, 0));
        setPendaftar.setShowHorizontalLines(false);
        setPendaftar.setShowVerticalLines(false);
        jScrollPane1.setViewportView(setPendaftar);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 250, 900, 340));

        penilaian.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Masukkan Penilaian.png"))); // NOI18N
        penilaian.setText("Masukkan Penilaian");
        penilaian.setBorderPainted(false);
        penilaian.setContentAreaFilled(false);
        penilaian.setFocusPainted(false);
        penilaian.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Masukkan Penilaian 2.png"))); // NOI18N
        getContentPane().add(penilaian, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 200, 210, 80));

        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home.png"))); // NOI18N
        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home 2.png"))); // NOI18N
        getContentPane().add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 280, 200, 80));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Validasi Pendaftar.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        setSize(new java.awt.Dimension(1296, 759));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Validasi_Pendaftar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Validasi_Pendaftar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Validasi_Pendaftar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Validasi_Pendaftar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Validasi_Pendaftar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ModalInput_Nilai;
    private javax.swing.JButton cancelButton;
    private javax.swing.JTextField field_Nilai;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton penilaian;
    private javax.swing.JTable setPendaftar;
    private javax.swing.JButton submitButton;
    // End of variables declaration//GEN-END:variables
}
