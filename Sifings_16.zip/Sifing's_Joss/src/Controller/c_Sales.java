/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class c_Sales extends CLass_Musik.Musik {

    private View.Sales_Home the_v;
    boolean statusButton_Profile = true;
    boolean statusButton_pemberitahuan = true;
    boolean statusButton_Distribusi = true;
    private View.Sifings_Login the_V2;
    private String username;

    public c_Sales(String username) {
        the_v = new View.Sales_Home();
        the_V2 = new View.Sifings_Login();
        this.username = username;

        the_v.setVisible(true);
        the_v.getPop_Profile().setVisible(false);
        the_v.getSubMenu_Distibusi().setVisible(false);
        the_v.getPunismentDistribusi().setVisible(false);
        the_v.getMasukkanDistribusi().setVisible(false);
        the_v.getLihatDistribusi().setVisible(false);
        the_v.getPunismentDistribusi().setVisible(false);
        the_v.getPop_Nama().setVisible(false);

        the_v.tombolProfile(new profileListner());
        the_v.tombolLogout(new logoutListener());
//        the_v.tombolDistribusi(new Distribusi_Listener());
        the_v.tombolDistribusi(new distribusiListner());
        the_v.tombolMasukkan_Distribusi(new Distribusi_Listener());
        the_v.tombolPunisment_Distribusi(new punismentListener());
        the_v.tombolLihat_Distribusi(new lihatTotalDistribusi());
        the_v.tombolPemberitahuan().addActionListener(new pemberitahuanListener());
        the_v.tombolGrafikku().addActionListener(new grafikku_Listener());
        
        setFiturPemberitahuan("off");
    }

    private class profileListner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusButton_Profile) {
                the_v.getPop_Profile().setVisible(true);
                the_v.getPop_Nama().setVisible(true);
                the_v.setNama(username);
                if (username.equalsIgnoreCase("tiara")) {
                    the_v.setImage_tiara().setVisible(true);
                } else if (username.equalsIgnoreCase("loadhi")) {
                    the_v.setImage_Loadhi().setVisible(true);
                } else if (username.equalsIgnoreCase("stanis")) {
                    the_v.setImage_Satan().setVisible(true);
                }
                statusButton_Profile = false;
            } else {
                the_v.getPop_Profile().setVisible(false);
                the_v.getPop_Nama().setVisible(false);
                if (username.equalsIgnoreCase("tiara")) {
                    the_v.setImage_tiara().setVisible(false);
                } else if (username.equalsIgnoreCase("loadhi")) {
                    the_v.setImage_Loadhi().setVisible(false);
                } else if (username.equalsIgnoreCase("stanis")) {
                    the_v.setImage_Satan().setVisible(false);
                }
                statusButton_Profile = true;

            }

        }

    }

    public void setFiturPemberitahuan(String status) {
        if (status.equalsIgnoreCase("on")) {
            the_v.FiturPemberitahuan().setVisible(true);
            the_v.tombolGrafikku().setVisible(true);
        } else if (status.equalsIgnoreCase("off")) {
            the_v.FiturPemberitahuan().setVisible(false);
            the_v.tombolGrafikku().setVisible(false);
        }
    }
    private class grafikku_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                new c_prestasiku(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Sales.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }
        
    }

    private class pemberitahuanListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (statusButton_pemberitahuan) {
                setFiturPemberitahuan("on");
                statusButton_pemberitahuan = false;
            } else {
                setFiturPemberitahuan("off");
                statusButton_pemberitahuan = true;
            }
        }

    }

    private class distribusiListner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusButton_Distribusi) {
                the_v.getSubMenu_Distibusi().setVisible(true);
                the_v.getPunismentDistribusi().setVisible(true);
                the_v.getMasukkanDistribusi().setVisible(true);
                the_v.getLihatDistribusi().setVisible(true);
                the_v.getPunismentDistribusi().setVisible(true);
                statusButton_Distribusi = false;
            } else {
                the_v.getPunismentDistribusi().setVisible(false);
                the_v.getMasukkanDistribusi().setVisible(false);
                the_v.getLihatDistribusi().setVisible(false);
                the_v.getPunismentDistribusi().setVisible(false);
                the_v.getSubMenu_Distibusi().setVisible(false);
                statusButton_Distribusi = true;
            }

        }

    }

    private void sembunyikanImage() {
        the_v.setImage_Loadhi().setVisible(false);
        the_v.setImage_Satan().setVisible(false);
        the_v.setImage_tiara().setVisible(false);
    }

    private class logoutListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane pane = new JOptionPane("Anda Yakin akan keluar");
            Object[] options = new String[]{"YES", "NO"};
            soundTombol();
            pane.setOptions(options);
            JDialog dialog = pane.createDialog(new JFrame(), "Message");
            dialog.show();
            Object obj = pane.getValue();
            if (obj.equals("YES")) {
                soundTombol();
                new c_Beranda();
                the_v.dispose();
            } else {
                the_v.getPop_Profile().setVisible(false);
                sembunyikanImage();
                the_v.getPop_Nama().setVisible(false);
            }
        }
    }

    private class Distribusi_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Distribusi(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Sales.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class punismentListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_riwayatDistribusi_Sales(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Sales.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class lihatTotalDistribusi implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_TotalDistribusi_Sales(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Sales.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }
}
