/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author Rini
 */
public class c_validasiGaji extends CLass_Musik.Musik {

    private View.ValidasiGaji_Direktur the_V;
    private Model.Pegawai the_M;
    private View.Sifings_Login the_V2;
    private String username;
    private boolean statusModal = true;

    private XYSeriesCollection dataset = new XYSeriesCollection();

    private XYSeries series = new XYSeries("Disribusi");
    private XYSeries seriesBeban = new XYSeries("Beban");

    public c_validasiGaji(String username) throws SQLException {
        the_V = new View.ValidasiGaji_Direktur();
        the_V2 = new View.Sifings_Login();
        the_M = new Model.Pegawai();
        the_V.setVisible(true);
        this.username = username;

        the_V.buttonValidasi(new Modal_Pop_Listner());
        the_V.setTable_PengujanGaji(the_M.getDataaPerubahan_Gaji());
        the_V.setModal().setVisible(false);
        the_V.setInputValidasi().setVisible(false);
        the_V.setCancel().setVisible(false);
        the_V.setSubmit().setVisible(false);
        the_V.setSubmit().addActionListener(new ValidasiListener());
        the_V.backHome(new backHome_Listner());
        the_V.grafik().setVisible(false);
        the_V.setCancel().addActionListener(new cancelListern());
        the_V.lihatPrestasi().addActionListener(new lihatPrestasi_Listener());
    }

    public XYDataset createDataset(int Periode[], int jumlahDstribusi[]) {
        series.clear();
        for (int i = 0; i < Periode.length; i++) {
            series.add(Periode[i], jumlahDstribusi[i]);
        }
        dataset.addSeries(series);
        return dataset;
    }

    public XYDataset createDatasetBeban(int Periode[], int jumlahDstribusi[]) {
        seriesBeban.clear();
        for (int i = 0; i < Periode.length; i++) {
            seriesBeban.add(Periode[i], jumlahDstribusi[i]);
        }
        dataset.addSeries(seriesBeban);
        return dataset;
    }

    private class cancelListern implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setModal().setVisible(false);
            the_V.setInputValidasi().setVisible(false);
            the_V.setCancel().setVisible(false);
            the_V.setSubmit().setVisible(false);
            the_V.editTable().setEnabled(true);
            statusModal = true;

        }

    }

    private class Modal_Pop_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusModal == true) {
                if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                    the_V.tampilPesan("Silahkan pilih baris tabel dahulu");
                } else {
                    the_V.setModal().setVisible(true);
                    the_V.setInputValidasi().setVisible(true);
                    the_V.setSubmit().setVisible(true);
                    the_V.setCancel().setVisible(true);
                    statusModal = false;
                }
            } else {
                the_V.setModal().setVisible(false);
                the_V.setInputValidasi().setVisible(false);
                the_V.setCancel().setVisible(false);
                the_V.setSubmit().setVisible(false);
                the_V.editTable().setEnabled(true);
                statusModal = true;
            }

        }

    }

    private class ValidasiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                the_V.tampilPesan("Silahkan pilih tabel terlebih dahulu");
            } else {
                if (the_V.getValidasi().isEmpty()) {
                    the_V.tampilPesan("Validasi tidak boleh kosong:");
                } else if (the_V.getValidasi().equalsIgnoreCase(" ")) {
                    the_V.tampilPesan("Validasi tidak boleh kosong");
                } else if (the_M.validasi_Gaji(the_V.getValidasi(), the_V.GetTable())) {
                    soundTombol();
                    the_V.tampilPesan("Sukses Input Nilai");
                    the_V.setModal().setVisible(false);
                    the_V.setInputValidasi().setVisible(false);
                    the_V.setSubmit().setVisible(false);
                    the_V.setCancel().setVisible(false);
                    try {
                        the_V.setTable_PengujanGaji(the_M.getDataaPerubahan_Gaji());
                    } catch (SQLException ex) {
                        Logger.getLogger(c_ValidasiDIstribusi.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    statusModal = false;
                } else {
                    the_V.tampilPesan("GAGAL");
                    the_V.editTable().setEnabled(true);
                    statusModal = true;
                }
            }
        }

    }

    private class backHome_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_Direktur(username);
            the_V.dispose();
        }

    }

    private class lihatPrestasi_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                the_V.grafik().setVisible(true);
                dataset.removeAllSeries();
                the_V.chart(createDataset(the_M.getID_Distribusi(the_V.GetTable()), the_M.getPrestasi(the_V.GetTable())));
                the_V.chart(createDatasetBeban(the_M.getID_Distribusi(the_V.GetTable()), the_M.getMInimal()));
                the_V.reset();
            } catch (SQLException ex) {
                Logger.getLogger(c_validasiGaji.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
