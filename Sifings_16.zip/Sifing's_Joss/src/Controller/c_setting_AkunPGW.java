/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pegawai;
import View.Sifings_Login;
import View.editProfile;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_setting_AkunPGW {

    private View.editProfile the_V;
    private View.Sifings_Login the_V2;
    private Model.Pegawai the_M;
    private String username;

    public c_setting_AkunPGW(String username) throws SQLException {
        the_V = new editProfile();
        the_V2 = new Sifings_Login();
        the_M = new Pegawai();
        this.username = username;
        the_V.setVisible(true);
        the_V.setNama(the_M.getNama(username));
        the_V.setUsername(the_M.getUseername(username));
        the_V.setPassword(the_M.getPassword(username));
        the_V.setAlamat(the_M.getAlamat(username));
        the_V.setKota(the_M.getKota(username));
        
        the_V.getSImpan().addActionListener(new perbarui_listener());
    }

    private class perbarui_listener implements ActionListener {

        @Override

        public void actionPerformed(ActionEvent ae) {
            int Ceknama = 0;
            int Ceknama_ANgka = 0;
            int Cekalamat = 0;
            int cekAlamatAngka = 0;
            int cekKOta = 0;
            int cekKOtaANgka = 0;
            char angka[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
            char everything[] = {'~', '`', '!', '@', '#', '#', '$', '%', '%', '^', '&', '*', '(', ')', '-', '_',
                '+', '=', '[', ']', ',', '{', '}', ':', ';', '"', '?', '/', '.', '>', '<', '|',};
            char nama[] = the_V.getNama().toCharArray();
            char alamat[] = the_V.getAlamat().toCharArray();
            char kota[] = the_V.getKota().toCharArray();

            for (int i = 0; i < nama.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (nama[i] == everything[j]) {
                        Ceknama++;
                    }
                }
            }
            for (int i = 0; i < nama.length; i++) {
                for (int j = 0; j < angka.length; j++) {
                    if (nama[i] == angka[j]) {
                        Ceknama_ANgka++;
                    }
                }
            }
            for (int i = 0; i < alamat.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (alamat[i] == everything[j]) {
                        Cekalamat++;
                    }
                }
            }
            for (int i = 0; i < alamat.length; i++) {
                for (int j = 0; j < angka.length; j++) {
                    if (alamat[i] == angka[j]) {
                        Ceknama_ANgka++;
                    }
                }
            }
            for (int i = 0; i < kota.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (kota[i] == everything[j]) {
                        cekKOta++;
                    }
                }
            }
            for (int i = 0; i < kota.length; i++) {
                for (int j = 0; j < angka.length; j++) {
                    if (kota[i] == angka[j]) {
                        cekKOtaANgka++;
                    }
                }
            }
            if (the_V.getNama().isEmpty()) {
                the_V.tampilPesan("Nama tidak boleh kosong");
            } else if (the_V.getUsername().isEmpty()) {
                the_V.tampilPesan("Username tidak boleh kosong");
            } else if (the_V.getPassword().isEmpty()) {
                the_V.tampilPesan("Password tidak boleh kosong");
            } else if (the_V.getAlamat().isEmpty()) {
                the_V.tampilPesan("Alamat tidak boleh kosong");
            } else if (the_V.getKota().isEmpty()) {
                the_V.tampilPesan("Kota tidak boleh kosong");
            } else if (Ceknama > 0) {
                the_V.tampilPesan("Nama anda tidak valid");
            } else if (Ceknama_ANgka > 0) {
                the_V.tampilPesan("Nama anda tidak boleh ada angka");
            } else if (Cekalamat > 0) {
                the_V.tampilPesan("Almata tidak valid");
            } else if (cekKOta > 0) {
                the_V.tampilPesan("Kota tidak valid");
            } else if (cekKOtaANgka > 0) {
                the_V.tampilPesan("Kota tidak boleh ada angka");
            } else {
                try {
                    if (the_M.perbaruiAkun_Ku(the_V.getDataPerubahan(), the_M.getIDNYA(username))) {
                        the_V.tampilPesan("Data Berhasil diperbarui");
                        the_V.setNama(the_M.getNama(username));
                        the_V.setUsername(the_M.getUseername(username));
                        the_V.setPassword(the_M.getPassword(username));
                        the_V.setAlamat(the_M.getAlamat(username));
                        the_V.setKota(the_M.getKota(username));
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_setting_AkunPGW.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

}
