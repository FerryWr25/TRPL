/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.block.BlockBorder;
import org.jfree.chart.labels.StandardXYToolTipGenerator;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class ValidasiGaji_Direktur extends javax.swing.JFrame {

    private ChartPanel chartPanel;

    public ValidasiGaji_Direktur() {
        initComponents();
        this.setLocationRelativeTo(this);
        chart(createDatasetNull());
        panel.add(chartPanel);
    }

    public void chart(XYDataset dataset) {
        JFreeChart chart = ChartFactory.createXYLineChart("Average salary per age", "Periode", "Jumlah Distribusi", dataset, PlotOrientation.VERTICAL, true, true, false);

        chartPanel = new ChartPanel(chart);

        XYPlot plot = chart.getXYPlot();

        NumberAxis xAxis = (NumberAxis) plot.getDomainAxis();
        xAxis.setTickUnit(new NumberTickUnit(1));

        NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
        yAxis.setTickUnit(new NumberTickUnit(100));

        XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();

        renderer.setSeriesPaint(0, Color.RED);
        renderer.setSeriesStroke(0, new BasicStroke(2.0f));

        renderer.setSeriesPaint(1, Color.BLUE);
        renderer.setSeriesStroke(1, new BasicStroke(2.0f));

        renderer.setSeriesPaint(2, Color.MAGENTA);
        renderer.setSeriesStroke(2, new BasicStroke(2.0f));

        renderer.setSeriesPaint(3, Color.DARK_GRAY);
        renderer.setSeriesStroke(3, new BasicStroke(2.0f));

        plot.setRenderer(renderer);
        plot.setBackgroundPaint(Color.white);

        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(Color.BLACK);

        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(Color.BLACK);

        chart.getLegend().setFrame(BlockBorder.NONE);

        chart.setTitle(new TextTitle("Grafik Distribusi ", new Font("Serif", Font.BOLD, 18)));

        NumberFormat format = NumberFormat.getNumberInstance();
        format.setMaximumFractionDigits(2);

        StandardXYToolTipGenerator ttg = new StandardXYToolTipGenerator("{2}", format, format);
        renderer.setBaseToolTipGenerator(ttg);

        chartPanel.setMouseZoomable(false);
        chartPanel.setInitialDelay(0);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
    }

    private XYDataset createDatasetNull() {

        XYSeriesCollection dataset = new XYSeriesCollection();
        return dataset;
    }

    public void reset() {
        panel.removeAll();
        panel.add(chartPanel);
        chartPanel.revalidate();
        chartPanel.repaint();
        panel.revalidate();
        panel.repaint();
    }

    public void backHome(ActionListener action) {
        this.home.addActionListener(action);
    }

    public void setTable_PengujanGaji(DefaultTableModel table) {
        this.tabelPengajuan_Gaji.setModel(table);
    }

    public void tampilPesan(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public int tampilPeringatan(String pesan) {
        return JOptionPane.showConfirmDialog(this, pesan, null, JOptionPane.YES_NO_OPTION);
    }

    public int getSelectedRow() {
        return this.tabelPengajuan_Gaji.getSelectedRow();
    }

    public String GetTable() {
        return this.tabelPengajuan_Gaji.getValueAt(this.getSelectedRow(), 0).toString();
    }

    public void buttonValidasi(ActionListener action) {
        this.validasiButton.addActionListener(action);
    }
    public JPanel grafik(){
        return panel;
    }


    public JLabel setModal() {
        return ModalInput_Nilai;
    }

    public JComboBox setInputValidasi() {
        return comboValidasi;
    }

    public JButton setSubmit() {
        return submitButton;
    }

    public JButton lihatPrestasi() {
        return lihatPrestasi;
    }

    public JButton setCancel() {
        return cancelButton;
    }

    public JTable editTable() {
        return tabelPengajuan_Gaji;
    }

    public String getValidasi() {
        String nilai = (String) this.comboValidasi.getSelectedItem();
        return nilai;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        validasiButton = new javax.swing.JButton();
        home = new javax.swing.JButton();
        lihatPrestasi = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        comboValidasi = new javax.swing.JComboBox();
        ModalInput_Nilai = new javax.swing.JLabel();
        panel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelPengajuan_Gaji = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        validasiButton.setText("Validasi");
        getContentPane().add(validasiButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 180, 160, 50));

        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home.png"))); // NOI18N
        home.setBorderPainted(false);
        home.setContentAreaFilled(false);
        home.setFocusPainted(false);
        home.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home 2.png"))); // NOI18N
        getContentPane().add(home, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 320, 190, 80));

        lihatPrestasi.setText("Lihat Prestasi");
        getContentPane().add(lihatPrestasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(1100, 260, 160, 50));

        cancelButton.setText("CANCEL");
        getContentPane().add(cancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 470, 90, 30));

        submitButton.setText("SUBMIT");
        getContentPane().add(submitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 470, 90, 30));

        comboValidasi.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " ", "Menunggu Verifikasi", "Terverifikasi" }));
        getContentPane().add(comboValidasi, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 420, 210, 30));

        ModalInput_Nilai.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/PopUp Masukkan Penilaian.png"))); // NOI18N
        getContentPane().add(ModalInput_Nilai, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 340, 340, 210));

        panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        panel.setLayout(new java.awt.GridLayout(1, 0));
        getContentPane().add(panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 250, 450, 350));

        tabelPengajuan_Gaji.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabelPengajuan_Gaji);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 460, 350));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Daftar Perubahan Gaji Karyawan.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

        setBounds(0, 0, 1296, 759);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ValidasiGaji_Direktur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ValidasiGaji_Direktur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ValidasiGaji_Direktur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ValidasiGaji_Direktur.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ValidasiGaji_Direktur().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ModalInput_Nilai;
    private javax.swing.JButton cancelButton;
    private javax.swing.JComboBox comboValidasi;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton lihatPrestasi;
    private javax.swing.JPanel panel;
    private javax.swing.JButton submitButton;
    private javax.swing.JTable tabelPengajuan_Gaji;
    private javax.swing.JButton validasiButton;
    // End of variables declaration//GEN-END:variables
}
