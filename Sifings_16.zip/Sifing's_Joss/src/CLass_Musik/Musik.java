/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CLass_Musik;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Musik {

    public Musik() {
        
    }
    public void soundTombol() {
        try {
            AudioInputStream audio = AudioSystem.getAudioInputStream(new File("src//Sound//zzz.wav"));
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        } catch (Exception ex) {
            Logger.getLogger(Musik.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
