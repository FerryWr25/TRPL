/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;

public class Pegawai extends Model_Master {

    ResultSet rs;
    private String ID_Jabatan;
    private String ID_Calon_Pegawai;
    private String catatanku;
    private String ID_Calon_Pegawai_Ditambah;
    private String Keahlian;
    private String Keterbatasan;
    private String Alasan;
    private String Total;
    private String DataPegawaiBaru;

    public Pegawai() throws SQLException {
        super();
    }

    public String getLEVEL(String username) throws SQLException {
        String query = "select ID_Jabatan from pegawai where Username = '" + username + "' ";
        System.out.println(query);
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Jabatan");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public boolean insertDataPeg(String[] Data) {
        String query = "INSERT INTO `calon_pegawai` (`ID_Calon_Pegawai`, `Nama_Pegawai`, `Jenis_Kelamin`, `Agama`,"
                + " `Tanggal_Lahir`, `Alamat`, `Kota`, `No_Telp`, `Keterampilan`, `Keterbatasan`, `Alasan`)"
                + "VALUES (NULL, '" + Data[0] + "', '" + Data[1] + "', '" + Data[2] + "', '" + Data[3] + "', '" + Data[4] + "',"
                + "'" + Data[5] + "', '" + Data[6] + "', '" + Data[7] + "', '" + Data[8] + "',"
                + "'" + Data[9] + "');";
        System.out.println(query);
        return getStatusQuery(query);
    }

    //umumkan pendaftar
    public boolean insertDataPeg_Baru(String[] Data) {
        String query = "INSERT INTO `pegawai`(`ID_Pegawai`, `Nama_Pegawai`, `Username`, `Password`, `Jenis_kelamin`, `Agama`, "
                + "`ID_Jabatan`, `Tanggal_Lahir`, `Alamat`, `Kota`, `Photo`, `No_Telp`, `Catatan`, `Status_pegawai`, `Jumlah_Punisment`) "
                + "VALUES (NULL,'" + Data[1] + "','" + Data[1] + "','lalala" + "','" + Data[4] + "','" + Data[5] + "',3,'" + Data[7] + "',"
                + "'" + Data[8] + "','" + Data[9] + "','-" + "','" + Data[11] + "','" + Data[12] + "','Pegawai tetap" + "',0" + ")";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean getPegawai(String username, String password) throws SQLException {
        String query = "SELECT * FROM `pegawai` WHERE Username = '" + username + "' AND Password ='" + password + "'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                ID_Jabatan = rs.getString("ID_Jabatan");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return status;
    }

    public String getJabatan() {
        return ID_Jabatan;
    }

    public DefaultTableModel getData_Distribusi() throws SQLException {
        String kolom[] = {"Nama_Pegawai", "Jumlah_Kirim", "Tanggal", "TotalHarga"};
        String Query = "select p.Nama_Pegawai,SUM(Jumlah_Pengiriman),d.Tanggal_Distribusi, "
                + "SUM(d.Harga) from distribusi d join beban_distribusi b on(d.ID_Beban_Distribusi=b.ID_Beban_Distribusi) "
                + "join pegawai p on (p.ID_Pegawai = d.ID_Pegawai) "
                + "group by d.ID_Pegawai , d.Tanggal_Distribusi ";
        return getDataTabel(kolom, Query);
    }

    public String getNomerSurat() throws SQLException {
        String query = "select MAX(ID_Calon_Pegawai) from calon_pegawai order by ID_Calon_Pegawai desc";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                ID_Calon_Pegawai = rs.getString("MAX(ID_Calon_Pegawai)");
                System.out.println(ID_Calon_Pegawai);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return ID_Calon_Pegawai;
    }

    ///addd toko
    public boolean insertDataToko(String[] Data) {
        String query = "INSERT INTO `toko` (`ID_Toko`, `NamaToko`, `Nama_Pemilik`, `Alamat`, `No_Telp`) VALUES "
                + "(NULL, '" + Data[0] + "', '" + Data[1] + "', '" + Data[2] + "', '" + Data[3] + "');";
        System.out.println(query);
        return getStatusQuery(query);
    }

    //pendaftar
    public DefaultTableModel getData_Pendaftar() throws SQLException {
        String kolom[] = {"Nama", "Jenis Kelamin", "Agama", "Alamat"};
        String Query = "select Nama_Pegawai ,Jenis_Kelamin,Agama,Alamat  from calon_pegawai";
        return getDataTabel(kolom, Query);
    }

    public DefaultTableModel getData_Pendaftar_Validasi() throws SQLException {
        String kolom[] = {"No", "Nama", "Jenis Kelamin", "Agama", "Alamat"};
        String Query = "select ID_Calon_Pegawai, Nama_Pegawai ,Jenis_Kelamin,Agama,Alamat  from calon_pegawai";
        return getDataTabel(kolom, Query);
    }

    public DefaultTableModel getData_Pendaftar_Recomendasi() throws SQLException {
        String kolom[] = {"Nama", "Jenis Kelamin", "Agama", "Alamat"};
        String Query = "select Nama_Pegawai, Jenis_Kelamin, Agama ,Alamat from calon_pegawai where (Keterampilan like '%marketing%' and Keterbatasan like '%komputer%') or (Keterampilan like '%marketing%' and Keterbatasan like '%speaking%') \n"
                + "or (Keterampilan like '%team%' and Keterbatasan like '%speaking%') or \n"
                + "(Keterampilan like '%team%' and Keterbatasan like '%komputer%')";
        return getDataTabel(kolom, Query);
    }

    ////memasukkan nilai pendaftar pegawai 
    public boolean insertDataNilai(String Data, String id) {
        String query = "UPDATE `calon_pegawai` SET `Nilai` = '" + Data + "' WHERE `calon_pegawai`.`ID_Calon_Pegawai` = " + id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public DefaultTableModel getDataPendaftar_Lolos(String Batas) throws SQLException {
        String kolom[] = {"Nama Pendaftar", "Jenis Kelamin", "Agama", "Alamat", "NO_Telp"};
        String Query = "SELECT Nama_Pegawai,Jenis_Kelamin,Agama,Alamat,No_Telp from calon_pegawai ORDER by "
                + "Nilai desc limit " + Batas;
        return getDataTabel(kolom, Query);
    }

    public DefaultTableModel getDataPendaftar_TOTAL() throws SQLException {
        String kolom[] = {"Nama Pendaftar", "Jenis Kelamin", "Agama", "Alamat", "No_Telp", "Nilai"};
        String Query = "select Nama_Pegawai,Jenis_Kelamin,Agama, Alamat,No_Telp,Nilai from calon_pegawai "
                + "where Nilai <> 0 order by Nilai desc";
        return getDataTabel(kolom, Query);
    }

    ////ambil catatan pribadi
    //ambil data buat diuumkan
//    ambil id nilai terbesar
    public String[] getID_LOLOS(String batas) throws SQLException {
        String query = "select ID_Calon_Pegawai from calon_pegawai ORDER by Nilai desc limit " + batas;
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        String ID[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        ID = new String[hitung];
        int i = 0;
        while (hasil.next()) {
            ID[i] = hasil.getString(1);
            i++;
        }
        return ID;
    }

    public String getNamaLOLOS(String id) throws SQLException {
        String query = "select Nama_Pegawai from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Nama_Pegawai");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public boolean insertaryawanBaru(String Data, String Nama, String username, String password, String jenKel, String Agama,
            String IdJbatan, String TTL, String Alamat, String Kota, String Photo, String NO_Telp,
            String Catatan, String StatusPGwai, String jumlahPunsMent, String gaji, String status) {
        String query = "INSERT INTO `pegawai`(`ID_Pegawai`, `Nama_Pegawai`, `Username`, `Password`, `Jenis_kelamin`, `Agama`,"
                + " `ID_Jabatan`, `Tanggal_Lahir`, `Alamat`, `Kota`, `Photo`, `No_Telp`, `Catatan`, `Status_pegawai`, `Jumlah_Punisment` , `Gaji`, `Status_Gaji`) "
                + "VALUES (NULL,'" + Nama + "','" + username + "','" + password + "','" + jenKel + "','" + Agama + "'," + 3 + ",'" + TTL + "',"
                + "'" + Alamat + "','" + Kota + "','-','" + NO_Telp + "','-','Pegawai tetap',0,'" + gaji + "','" + status + "')";
        System.out.println(query);
        return getStatusQuery(query);
    }

    public boolean Hapus_DataPgwai_Lama(String id) {
        String query = "DELETE FROM `calon_pegawai` WHERE ID_Calon_Pegawai = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public String getUsernameLOLOS(String id) throws SQLException {
        String query = "select Nama_Pegawai from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Nama_Pegawai");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getPasswordLOLOS(String id) throws SQLException {
        String query = "select Nama_Pegawai from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Nama_Pegawai");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getJenisKelamin_LOLOS(String id) throws SQLException {
        String query = "select Jenis_Kelamin from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Jenis_Kelamin");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getJenisAgama_LOLOS(String id) throws SQLException {
        String query = "select Agama from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Agama");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getTTL_LOLOS(String id) throws SQLException {
        String query = "select Tanggal_Lahir  from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Tanggal_Lahir");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getAlamat_LOLOS(String id) throws SQLException {
        String query = "select Alamat from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Alamat");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getKota_LOLOS(String id) throws SQLException {
        String query = "select Kota from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("Kota");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    public String getNo_Telp_LOLOS(String id) throws SQLException {
        String query = "select No_Telp from calon_pegawai where ID_Calon_Pegawai = " + id;
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                DataPegawaiBaru = rs.getString("No_Telp");
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return DataPegawaiBaru;
    }

    ///diperbarui gaji karyawan
    public DefaultTableModel getDataaryawanGaji() throws SQLException {
        String kolom[] = {"ID", "Nama", "Jenis Kelamin", "Alamat", "Kota", "JML_Gagal", "Gaji"};
        String Query = "select ID_Pegawai, Nama_Pegawai,Jenis_kelamin,Alamat,Kota,Jumlah_Punisment,Gaji from pegawai";
        return getDataTabel(kolom, Query);
    }

    public boolean insertGaji_Sales(String Data, String id) {
        String query = "UPDATE `pegawai` SET `Gaji` = '" + Data + "' WHERE `ID_Pegawai` = " + id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }

    //setting akun
    public DefaultTableModel getDataaryawanBaru_Seting() throws SQLException {
        String kolom[] = {"ID", "Nama", "Jenis Kelamin", "Password"};
        String Query = "select ID_Pegawai, Nama_Pegawai,Jenis_kelamin , Password from pegawai where ID_Jabatan"
                + " not BETWEEN 1 and 2 order by ID_Pegawai desc";
        return getDataTabel(kolom, Query);
    }

    public boolean insertPassword_Sales(String Data, String id) {
        String query = "UPDATE `pegawai` SET `Password` = '" + Data + "' WHERE `ID_Pegawai` = " + id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }
//    perbarui status jika merubah gaji karyawan

    public boolean updateStatus_Gaji(String id) {
        String query = "update pegawai set Status_Gaji = 'Menunggu Verifikasi' where ID_Pegawai = " + id;
        System.out.println(query);
        return getStatusQuery(query);
    }

    public DefaultTableModel getDataaPerubahan_Gaji() throws SQLException {
        String kolom[] = {"ID", "Nama", "Jenis Kelamin", "Status_Gaji", "Gaji "};
        String Query = "select ID_Pegawai,Nama_Pegawai,Jenis_kelamin, Status_Gaji,Gaji from pegawai "
                + "where Status_Gaji = 'Menunggu Verifikasi' and ID_Pegawai not BETWEEN 1 and 2 ";
        return getDataTabel(kolom, Query);
    }

    public boolean validasi_Gaji(String Data, String id) {
        String query = "UPDATE `pegawai` SET `Status_Gaji` = '" + Data + "' WHERE `ID_Pegawai` = " + id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }
    //perbari gaji HRD

    public DefaultTableModel getDataaPerubahan_Gaji_HRD() throws SQLException {
        String kolom[] = {"ID", "Nama", "Jenis Kelamin", "Gaji"};
        String Query = "select ID_Pegawai, Nama_Pegawai,Jenis_kelamin,Gaji from pegawai where ID_Jabatan = 2";
        return getDataTabel(kolom, Query);
    }

    public boolean updateGaji_HRD(String Data, String id) {
        String query = "UPDATE `pegawai` SET `Gaji` = '" + Data + "' ,Status_Gaji = 'Terverifikasi' WHERE `ID_Pegawai` = " + id + ";";
        System.out.println(query);
        return getStatusQuery(query);
    }
//     grafik prestasi sales

    public int[] getID_Distribusi(String id) throws SQLException {
        String query = "select ID_Beban_Distribusi from distribusi where ID_Pegawai = " + id + " AND Status_Distribusi = 'Verifikasi' GROUP BY ID_Beban_Distribusi ORDER BY ID_Beban_Distribusi ASC";
        System.out.println(query);
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Beban[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Beban = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Beban[i] = hasil.getInt(1);
            i++;
        }
        return Beban;
    }

    public int[] getPrestasi(String id) throws SQLException {
        String query = "select SUM(Jumlah_Pengiriman) from distribusi where ID_Pegawai= " + id + "  GROUP BY ID_Beban_Distribusi ORDER BY ID_Beban_Distribusi asc";
        System.out.println(query);
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Minimal[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Minimal = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Minimal[i] = hasil.getInt(1);
            i++;
        }
        return Minimal;
    }
//    lihat beban sales

    public int[] getMInimal() throws SQLException {
        String query = "select JmlMininal_PenjualanSales from beban_distribusi";
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Minimal[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Minimal = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Minimal[i] = hasil.getInt(1);
            i++;
        }
        return Minimal;
    }

    //tentang di grafikku
    public int[] getID_DistribusiKU(String nama) throws SQLException {
        String query = "select d.ID_Beban_Distribusi from distribusi d join pegawai p on (d.ID_Pegawai=p.ID_Pegawai) where p.Nama_Pegawai like  '%" + nama + "%' "
                + "AND d.Status_Distribusi = 'Verifikasi' GROUP BY d.ID_Beban_Distribusi ORDER BY d.ID_Beban_Distribusi ASC ";
        System.out.println(query);
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Beban[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Beban = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Beban[i] = hasil.getInt(1);
            i++;
        }
        return Beban;
    }

    public int[] getPrestasiKU(String nama) throws SQLException {
        String query = "select SUM(d.Jumlah_Pengiriman) from distribusi d join pegawai p on (d.ID_Pegawai=p.ID_Pegawai) "
                + "where p.Nama_Pegawai like '%" + nama + "%'"
                + " GROUP BY d.ID_Beban_Distribusi ORDER BY d.ID_Beban_Distribusi asc ";
        System.out.println(query);
        boolean status = false;
        ResultSet hasil = con.getResult(query);
        int Minimal[];
        int hitung = 0;
        while (hasil.next()) {
            hitung++;
        }
        hasil.beforeFirst();
        Minimal = new int[hitung];
        int i = 0;
        while (hasil.next()) {
            Minimal[i] = hasil.getInt(1);
            i++;
        }
        return Minimal;
    }

    public String getGajiku(String nama) throws SQLException {
        String query = "select Gaji from pegawai where Username = '" + nama + "' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Gaji");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getStatus_Gajiku(String nama) throws SQLException {
        String query = "select Status_Gaji from pegawai where Username like '" + nama + "'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Status_Gaji");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    ///edit akun pengguna
    public String getNama(String nama) throws SQLException {
        String query = "select Nama_Pegawai from pegawai where Nama_Pegawai like '%" + nama + "%'";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Nama_Pegawai");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getUseername(String nama) throws SQLException {
        String query = "select Username from pegawai where username like '%" + nama + "%' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Username");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getPassword(String nama) throws SQLException {
        String query = "select Password  from pegawai where username like '%" + nama + "%' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Password");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getAlamat(String nama) throws SQLException {
        String query = "select Alamat from pegawai where username like '%" + nama + "%' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Alamat");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public String getKota(String nama) throws SQLException {
        String query = "select Kota from pegawai where username like '%" + nama + "%' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("Kota");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }

    public boolean perbaruiAkun_Ku(String Data[], String id) {
        String query = "UPDATE `pegawai` SET `Nama_Pegawai`= '" + Data[0] + "'  ,`Username`='" + Data[1] +
                "',`Password`='"+Data[2]+"',`Alamat`= '"+Data[3]+"',`Kota`= '"+Data[4]+"' where ID_Pegawai = " +id;
        System.out.println(query);
        return getStatusQuery(query);
    }
    public String getIDNYA(String nama) throws SQLException {
        String query = "select ID_Pegawai from pegawai where Username like '%"+nama+"%' ";
        boolean status = false;
        try {
            rs = con.getResult(query);
            if (rs.next()) {
                status = true;
                Total = rs.getString("ID_Pegawai");
                System.out.println(Total);
            }
        } catch (SQLException e) {
            System.out.println("Salah");
        }
        return Total;
    }
}
