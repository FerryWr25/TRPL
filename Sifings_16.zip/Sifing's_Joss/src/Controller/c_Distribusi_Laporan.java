/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_Distribusi_Laporan extends CLass_Musik.Musik {

    private View.Direktur_Distributor the_V;
    private View.Sifings_Login the_V2;
    private Model.Distribusi the_M;
    private boolean StatusTarget = true;
    private int batas, hasilPrediksi_jml,sisaSemenNya;
    private String username;

    public c_Distribusi_Laporan(String username) throws SQLException {
        the_V = new View.Direktur_Distributor();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Distribusi();

        the_V.setVisible(true);
        the_V.setTableBeban_Ditribusi(the_M.getData_Beban());
        batas = Integer.parseInt(the_M.getPeriode_Angka());
        the_V.tombolRealisasikan(new buatBeban_Listener());
        the_V.tombolBack_Home(new backTo_Home());
        int sisaSemen = 0;

//        set sisa semen 
        JalankanMetodeNya_distribusi();
        JalankanMetode_Minimal_Distribusi();

    }

    private void JalankanMetodeNya_distribusi() throws SQLException {
        int p1, p2, p3, p4, rata1, rata2, rata1dan2;
        int isi[] = new int[batas];
        if (batas <= 4) {
            for (int i = isi.length - 1; i >= 0; i--) {
                isi[i] = Integer.parseInt(the_M.getDATA_Periode(i + 1));
                System.out.println(isi[i]);
            }
            System.out.println("/////////////");
            p1 = isi[3];
            p2 = isi[2];
            rata1 = (p1 + p2) / 2;
            p3 = isi[1];
            p4 = isi[0];
            rata2 = (p3 + p4) / 2;
            rata1dan2 = (rata1 + rata2) / 2;
            System.out.println(rata1dan2);

        } else {
            for (int i = isi.length - 1; i >= 0; i--) {
                isi[i] = Integer.parseInt(the_M.getDATA_Periode(i + 1));
                System.out.println(isi[i]);
            }
            System.out.println("/////////////");
            p1 = isi[isi.length - 1];
            p2 = isi[isi.length - 2];
            rata1 = (p1 + p2) / 2;
            p3 = isi[isi.length - 3];
            p4 = isi[isi.length - 4];
            rata2 = (p3 + p4) / 2;
            rata1dan2 = (rata1 + rata2) / 2;
            hasilPrediksi_jml = rata1dan2;
            System.out.println(rata1dan2);
            int persediaan = Integer.parseInt(the_M.getSisaSemen());

            //SISA SEMEN
            int totalPengadaan = Integer.parseInt(the_M.getTotalPengadaan());
            int totalKirim = Integer.parseInt(the_M.getTotalPengiriman());
            sisaSemenNya = totalPengadaan - totalKirim;
            the_V.setSisa_Semen(sisaSemenNya + "");

            int prediksi_FIX = (hasilPrediksi_jml - sisaSemenNya);
            the_V.setTambahan(prediksi_FIX + "");
            the_V.setPrediksi(hasilPrediksi_jml + "");
            the_V.setTextJmlah(prediksi_FIX + "");
        }
    }

    private void JalankanMetode_Minimal_Distribusi() throws SQLException {
        int jumlahPekerja = Integer.parseInt(the_M.getPekerja());
        System.out.println("jml pekerja : " + jumlahPekerja);
        int deviasi = (int) ((hasilPrediksi_jml / jumlahPekerja) * 0.05);
        System.out.println("deviasi : " + deviasi);
        int saranMinimal = (hasilPrediksi_jml / jumlahPekerja) - deviasi;
        the_V.setTextJmlah_minimal(saranMinimal + "");
    }

    private class buatBeban_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                if (the_M.insertDataBeban(the_V.getDataBeban(),sisaSemenNya+"")) {
                    the_V.tampilPesan("Sukses Buat");
                    the_V.setTableBeban_Ditribusi(the_M.getData_Beban());
                } else {
                    the_V.tampilPesan("GAGAL proses input");
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_Distribusi_Laporan.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    private class backTo_Home implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Direktur(username);
            the_V.dispose();
        }

    }

}
