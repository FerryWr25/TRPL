/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Pegawai;
import Print_Kartu.Beranda;
import View.Register;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.sql.SQLException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class c_Register extends CLass_Musik.Musik {

    public String NamaPakek = Register.namaPendaftar;
    private View.Register the_V;
    private Model.Pegawai the_M;

    public c_Register() throws SQLException {
        this.the_V = new Register();
        this.the_M = new Pegawai();
        the_V.tombolSubmit(new SubmitListener());
        the_V.tombolBack_Home(new backHome_Listener());
        the_V.setVisible(true);
        the_V.getModal_Print().setVisible(false);
        the_V.getModal_Download().setVisible(false);
        the_V.getModal_Exit().setVisible(false);
        the_V.getWOrd().setVisible(false);
        the_V.tombolPrintKartu(new modalCetakKartu());
        the_V.tombolKeluarModal(new keluarModalListener());
        the_V.setCOmboJengkeel(" ");
        the_V.setCOmboAgama(" ");
        the_V.setCOmboKeterbatasan(" ");
        the_V.setCOmboKeahlian(" ");
    }

    private class SubmitListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            char name[] = the_V.getNamaPendaftar().toCharArray();
            char no_telp[] = the_V.getNomer_Telp().toCharArray();
            char alamat[] = the_V.getAlamat().toCharArray();
            char kota[] = the_V.getKOta().toCharArray();
            int cekNama = 0;
            int cekalamat = 0;
            int cekKota = 0;
            int cekNomer = 0;
            char huruf[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

            char everything[] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '~', '`', '!', '@', '#', '#', '$', '%', '%', '^', '&', '*', '(', ')', '-', '_',
                '+', '=', '[', ']', ',', '{', '}', ':', ';', '"', '?', '/', '.', '>', '<', '|', ' '};
            for (int i = 0; i < name.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (name[i] == everything[j]) {
                        cekNama++;
                    }
                }
            }
            for (int i = 0; i < alamat.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (alamat[i] == everything[j]) {
                        cekalamat++;
                    }
                }
            }
            for (int i = 0; i < kota.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (kota[i] == everything[j]) {
                        cekKota++;
                    }
                }
            }
            for (int i = 0; i < no_telp.length; i++) {
                for (int j = 0; j < huruf.length; j++) {
                    if (no_telp[i] == huruf[j]) {
                        cekNomer++;
                    }
                }
            }

            if (the_V.getNamaPendaftar().isEmpty()) {
                the_V.tampilPesan("Nama Tidak Boleh Kosong");
            } else if (the_V.getAlamat().isEmpty()) {
                the_V.tampilPesan("Alamat Tidak Boleh Kosong");
            } else if (the_V.getKOta().isEmpty()) {
                the_V.tampilPesan("Kota Tidak Boleh Kosong");
            } else if (the_V.getComboJenis_Kel().getSelectedItem().equals(" ")) {
                the_V.tampilPesan("Jenis Kelamin Tidak Boleh Kosong");
            } else if (the_V.getAgama_set().getSelectedItem().equals(" ")) {
                the_V.tampilPesan("Agama Tidak Boleh Kosong");
            } else if (the_V.getNomer_Telp().isEmpty()) {
                the_V.tampilPesan("Nomer Telp Tidak Boleh Kosong");
            } else if (the_V.getKeahian_set().getSelectedItem().equals(" ")) {
                the_V.tampilPesan("Keahlian Tidak Boleh Kosong");
            } else if (the_V.getKeterbatasan_set().getSelectedItem().equals(" ")) {
                the_V.tampilPesan("Keterbatasan Tidak Boleh Kosong");
            } else if (the_V.getAlasan().isEmpty()) {
                the_V.tampilPesan("AlasanTidak Boleh Kosong");
            } else if (the_V.getNomer_Telp().length() > 13) {
                the_V.tampilPesan("Nomer Terlalu panjang");
            } else if (the_V.getNomer_Telp().length() < 12) {
                the_V.tampilPesan("Nomer Terlalu pendek");
            } else if (cekNama > 0) {
                the_V.tampilPesan("Nama Anda tidak valid");
            } else if (cekalamat > 0) {
                the_V.tampilPesan("alamat yang anda isi tidak valid");
            } else if (cekKota > 0) {
                the_V.tampilPesan("Kota yang anda isi tidak valid");
            } else if (cekNomer > 0) {
                the_V.tampilPesan("Silahkan masukkannomer dengan format angka");
            } else {
                the_M.insertDataPeg(the_V.getDataPendaftar());
                the_V.setTombolButton_Submit(false);
                the_V.setTombolButton_Cancel(false);
                the_V.setTombolButton_Home(false);
                the_V.getAgama_set().setVisible(false);
                the_V.getComboJenis_Kel().setVisible(false);
                the_V.getKeahian_set().setVisible(false);
                the_V.getKeterbatasan_set().setVisible(false);
                the_V.getTanggal_set().setVisible(false);
                the_V.setKota().setVisible(false);
                the_V.getWOrd().setVisible(true);
                the_V.getAlamat_Set().setVisible(false);
                the_V.getNama_Set().setVisible(false);
                the_V.getModal_Print().setVisible(true);
                the_V.getModal_Exit().setVisible(false);
                the_V.getModal_Download().setVisible(true);

            }
        }

    }

    private class SetKOsong implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setNama("");
            the_V.setAlamat("");
            the_V.setAlasan("");
            the_V.setKota("");
            the_V.setTombolButton_Submit(false);
            the_V.setTombolButton_Cancel(false);
            the_V.setTombolButton_Home(false);
        }

    }

    private class keluarModalListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Beranda();
            the_V.dispose();
        }

    }

    private class backHome_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Beranda();
            the_V.dispose();
        }

    }

    private class modalCetakKartu implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            FileOutputStream pdfFileout = null;
            Document fer = new Document();
            try {
                PdfWriter.getInstance(fer, new FileOutputStream("" + the_V.getNamaPendaftar() + ".pdf"));
                fer.open();

                Paragraph para1 = new Paragraph();
                para1.setAlignment(Element.ALIGN_CENTER);
                para1.add("Kartu Pendaftaran PT. MItra Maju Mapan");

                Paragraph para2 = new Paragraph();
                para2.setAlignment(Element.ALIGN_JUSTIFIED);
                para2.add("\nNama                              : " + the_V.getNamaPendaftar());

                Paragraph para3 = new Paragraph();
                para3.setAlignment(Element.ALIGN_JUSTIFIED);
                para3.add("\nAlamat                            : " + the_V.getAlamat());

                Paragraph para4 = new Paragraph();
                para4.setAlignment(Element.ALIGN_JUSTIFIED);
                para4.add("\nJenis Kelamin                 : " + the_V.getJenisKelamin());

                Paragraph para25 = new Paragraph();
                para25.setAlignment(Element.ALIGN_JUSTIFIED);
                para25.add("\nAgama                           : " + the_V.getJenisAgama());

                Paragraph para5 = new Paragraph();
                para5.setAlignment(Element.ALIGN_JUSTIFIED);
                try {
                    para5.add("\nNo_Pendafataran           : " + the_M.getNomerSurat());
                } catch (SQLException ex) {
                    Logger.getLogger(c_Register.class.getName()).log(Level.SEVERE, null, ex);
                }

                Paragraph para6 = new Paragraph();
                para6.setAlignment(Element.ALIGN_JUSTIFIED);
                para6.add("\nStatus                             : Dinyatakan diterima sebagai karyawan baru PT. Mitra Maju Mapan");

                Paragraph para7 = new Paragraph();
                para7.setAlignment(Element.ALIGN_JUSTIFIED);
                para7.add("\nTanggal Wawancara      : 12-Agustus-2017");
                para7.add("\n\nBerdasarkan hasil wawancara yang dilakukan oleh human resource management bahwasannya"
                        + " pengumuman ini bersifat privasi");

                para7.add("\n\nDengan ini saya menyatakan bersedia menjadi pegawai PT.Mitra Maju Mapan dengan jabatan"
                        + " Sales Distribusi dengan gaji pertama sebesar Rp. 2.000.000");

                Paragraph para8 = new Paragraph();
                Paragraph para9 = new Paragraph();
                Paragraph para10 = new Paragraph();
                Paragraph para11 = new Paragraph();

                para7.add("\n\n\n\nNB: Silahkan diserahkan pada bagian customer service PT. Mitra Maju Mapan");

                para10.add("\n\n\nManager HRD,                                                                  Direktur \n\n\n");
                para11.add("\n\n\nFerry Wiranto S,Kom                                                         Agung Prawiryo S.Kep");

                fer.add(para1);
                fer.add(para2);
                fer.add(para3);
                fer.add(para4);
                fer.add(para25);
                fer.add(para5);
                fer.add(para6);
                fer.add(para7);
                fer.add(para8);
                fer.add(para10);
                fer.add(para11);

                fer.close();
                System.out.println("Success!");
//                mergelaporan();
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Beranda.class.getName()).log(Level.SEVERE, null, ex);
            } catch (DocumentException ex) {
                Logger.getLogger(Beranda.class.getName()).log(Level.SEVERE, null, ex);
            }
            fer.open();
            the_V.setNama("");
            the_V.setAlamat("");
            the_V.setAlasan("");
            the_V.setKota("");
            the_V.setTombolButton_Submit(false);
            the_V.setTombolButton_Cancel(false);
            the_V.setTombolButton_Home(false);
            the_V.tampilPesan("Sukses Create Card");
            the_V.getModal_Exit().setVisible(true);
            the_V.setNama("");
            the_V.setAlamat("");
            the_V.setKota("");
            the_V.setAgama(" ");
            the_V.setJenisKL(" ");
            the_V.setKeAhlian(" ");
            the_V.setKeterbatasan(" ");
            the_V.setAlasan("");
        }

    }

}
