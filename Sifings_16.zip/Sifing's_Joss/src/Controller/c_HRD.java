/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Rini
 */
public class c_HRD extends CLass_Musik.Musik {

    private View.HRD_Home the_v;
    boolean statusButton_Profile = true;
    boolean statusSubmenu_Pemberitahuan = true;
    boolean statusSubmenu_KelolaKaryawan = true;
    boolean control_submenu_Pemberitahuan = true;
    boolean statusSubmenu_Distributor = true;
    private View.Sifings_Login the_V2;
    private String username;

    public c_HRD(String username) {
        this.username = username;
        the_v = new View.HRD_Home();
        the_V2 = new View.Sifings_Login();
        the_v.setVisible(true);
        the_v.getPop_Profile().setVisible(false);
        the_v.getSubPemberitahuan().setVisible(false);
        the_v.getSub_Menu_Punisment().setVisible(false);
        the_v.getSub_Menu_Rekrutment().setVisible(false);
        the_v.getPop_NamaHRD().setVisible(false);
        setFitur_kKaryawan("off");
        setFitur_Pemberitahuan("off");
        setFitur_Distributor("off");

        the_v.getSubDistributor().setVisible(false);
        the_v.getDstibusiSales().setVisible(false);
        the_v.getSubPencapaian().setVisible(false);
        the_v.getSubPersediaan().setVisible(false);

        the_v.getPendaftar().setVisible(false);
        the_v.tombolProfile(new profileListner());
        the_v.tombolLogout(new logoutListener());
        the_v.tombolPemberitahuan(new subMenu_pemberitahuan());
        the_v.tombolKelola_Karyawan(new subMenuKaryawan_Listener());
        the_v.tombol_Pendaftar(new subMenu_Pendaftar_Lstenr());
        the_v.tombol_Distributor(new SubDistributor_Listener());
        the_v.tombol_subDistribusi(new tombol_subDistribusi_Listner());
        the_v.tombol_Rekruitment(new RekrutmentListener());
        the_v.tombol_Punisment(new PunismentLIstener());
        the_v.tombolKaryawan_Baru(new karyawanBaru_Listener());
        the_v.tombolValidasiDistribusi(new validasiDitibusi());
        the_v.tombolGaji_Karyawan(new GajiListener());
        the_v.tombolakunBaru(new settingAkunBAru_Sales());
    }


    private void SembunyikanImage() {
        the_v.setImage_Bahri().setVisible(false);
        the_v.setImage_nila().setVisible(false);
        the_v.setName_HRD().setVisible(false);
    }

    private void setFitur_Pemberitahuan(String status) {
        if (status.equalsIgnoreCase("on")) {
            the_v.getSubPemberitahuan().setVisible(true);
            the_v.getSub_Menu_Punisment().setVisible(true);
            the_v.getSub_Menu_Rekrutment().setVisible(true);
            the_v.getPendaftar().setVisible(true);
        } else if (status.equalsIgnoreCase("off")) {
            the_v.getSubPemberitahuan().setVisible(false);
            the_v.getSub_Menu_Punisment().setVisible(false);
            the_v.getSub_Menu_Rekrutment().setVisible(false);
            the_v.getPendaftar().setVisible(false);
        }
    }

    private void setFitur_Distributor(String status) {
        if (status.equalsIgnoreCase("on")) {
            the_v.getSubDistributor().setVisible(true);
            the_v.getDstibusiSales().setVisible(true);
            the_v.getSubPencapaian().setVisible(true);
            the_v.getSubPersediaan().setVisible(true);
        } else if (status.equalsIgnoreCase("off")) {
            the_v.getSubDistributor().setVisible(false);
            the_v.getDstibusiSales().setVisible(false);
            the_v.getSubPencapaian().setVisible(false);
            the_v.getSubPersediaan().setVisible(false);

        }
    }

    private void setFitur_kKaryawan(String status) {
        if (status.equalsIgnoreCase("on")) {
            the_v.getPop_KelolaKaryawan().setVisible(true);
            the_v.getKaryawanBAru().setVisible(true);
            the_v.getKaryawanTetap().setVisible(true);
            the_v.getGaji().setVisible(true);
        } else if (status.equalsIgnoreCase("off")) {
            the_v.getPop_KelolaKaryawan().setVisible(false);
            the_v.getKaryawanBAru().setVisible(false);
            the_v.getKaryawanTetap().setVisible(false);
            the_v.getGaji().setVisible(false);
        }
    }

    private class validasiDitibusi implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                new c_ValidasiDIstribusi(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class karyawanBaru_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Pengumuman(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class subMenuKaryawan_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusSubmenu_KelolaKaryawan == true) {
                setFitur_kKaryawan("on");
                setFitur_Distributor("off");
                setFitur_Pemberitahuan("off");
                statusSubmenu_KelolaKaryawan = false;
                statusButton_Profile = true;
                statusSubmenu_Distributor = true;
            } else {
                setFitur_kKaryawan("off");
                statusSubmenu_KelolaKaryawan = true;
            }
        }

    }

    private class SubDistributor_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusSubmenu_Distributor == true) {
                setFitur_Distributor("on");
                setFitur_Pemberitahuan("off");
                setFitur_kKaryawan("off");
                statusSubmenu_Distributor = false;
                statusButton_Profile = true;
                statusSubmenu_KelolaKaryawan = true;
            } else {
                setFitur_Distributor("off");
                statusSubmenu_Distributor = true;
            }
        }
    }

    private class tombol_subDistribusi_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Distribusi_HRD(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class subMenu_pemberitahuan implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusSubmenu_Pemberitahuan == true) {
                setFitur_Pemberitahuan("on");
                setFitur_kKaryawan("off");
                setFitur_Distributor("off");
                statusSubmenu_Pemberitahuan = false;
                statusSubmenu_Distributor = true;
                statusSubmenu_KelolaKaryawan = true;

            } else {
                setFitur_Pemberitahuan("off");
                statusSubmenu_Pemberitahuan = true;
            }
        }

    }

    private class profileListner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusButton_Profile) {
                setFitur_Distributor("off");
                setFitur_Pemberitahuan("off");
                setFitur_kKaryawan("off");
                the_v.getPop_Profile().setVisible(true);
                the_v.getPop_NamaHRD().setVisible(true);
                the_v.setNamaHRD(username);
                System.out.println(username);
                if (username.equalsIgnoreCase("nila")) {
                    the_v.setImage_nila().setVisible(true);
                } else if (username.equalsIgnoreCase("bahri")) {
                    the_v.setImage_Bahri().setVisible(true);
                }
                statusButton_Profile = false;
            } else {
                the_v.getPop_Profile().setVisible(false);
                the_v.getPemberitahuan().setVisible(true);
                the_v.getPop_NamaHRD().setVisible(false);
                if (username.equalsIgnoreCase("nila")) {
                    the_v.setImage_nila().setVisible(false);
                } else if (username.equalsIgnoreCase("bahri")) {
                    the_v.setImage_Bahri().setVisible(false);
                }
                statusButton_Profile = true;
            }

        }

    }

    private class logoutListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane pane = new JOptionPane("Anda Yakin akan keluar");
            Object[] options = new String[]{"YES", "NO"};
            soundTombol();
            pane.setOptions(options);
            JDialog dialog = pane.createDialog(new JFrame(), "Message");
            dialog.show();
            Object obj = pane.getValue();
            if (obj.equals("YES")) {
                soundTombol();
                new c_Beranda();
                the_v.dispose();
            } else {
                the_v.getPop_Profile().setVisible(false);
                SembunyikanImage();
            }
        }
    }

    private class subMenu_Pendaftar_Lstenr implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Pendaftar_Karyawan(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class RekrutmentListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_validasiPendaftar(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class PunismentLIstener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_LaporanDistribusi_Gagal(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class GajiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Gaji(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class settingAkunBAru_Sales implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_settingAkun(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_HRD.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }
}
