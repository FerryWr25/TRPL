/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class c_Pendaftar_Karyawan extends CLass_Musik.Musik{

    private View.Karyawan_Register the_V;
    private View.Sifings_Login the_V2;
    private Model.Pegawai the_M;
    private String username;

    public c_Pendaftar_Karyawan(String username) throws SQLException {
        the_V = new View.Karyawan_Register();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Pegawai();
        the_V.setTablePendaftar(the_M.getData_Pendaftar());
        the_V.setVisible(true);
        the_V.setTableRecomendation(the_M.getData_Pendaftar_Recomendasi());
        the_V.tombolBack_Home(new kembali_home_Listener());

    }

    private class kembali_home_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_HRD(username);
            the_V.dispose();
        }

    }

}
