/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Rini
 */
public class c_Direktur extends CLass_Musik.Musik {

    private View.Direktur_Home the_v;
    boolean statusButton_Profile = true;
    boolean statusButton_Distributor = true;
    boolean statusButton_Evaluasi = true;
    private String username;

    public c_Direktur(String Username) {
        this.username = Username;
        the_v = new View.Direktur_Home();
        the_v.setVisible(true);
        the_v.getPop_Profile().setVisible(false);
        the_v.getDropDown_distributor().setVisible(false);
        the_v.setAddToko_btn().setVisible(false);
        the_v.setPrediksi_btn().setVisible(false);
        the_v.setListDIstribusi_btn().setVisible(false);
        the_v.getPop_Nama().setVisible(false);
        the_v.setImage().setVisible(false);
        the_v.setButtonKeluar().setVisible(false);
        ///fitur evaluasi karyawan
        the_v.getDropDown_Verifikasi().setVisible(false);
        the_v.setVerifikasiGaji().setVisible(false);
        the_v.setUbahGaji().setVisible(false);
        the_v.setGrafik().setVisible(false);

        the_v.tombolEvaluasi(new showDropDown_Evaluasi());

        the_v.tombolProfile(new profileListner());
        the_v.tombolLogout(new logoutListener());
        the_v.tomboldistributor(new showDropDown_Distribusi());
        the_v.addToko(new tambahToko_Listener());
        the_v.prediksi_btn(new prediksiListener());
        the_v.setVerifikasiGaji().addActionListener(new Validsi_Listener());
        the_v.setUbahGaji().addActionListener(new Gaji_HRD_Listener());
        
        the_v.setGrafik().addActionListener(new Grafik_Listener());
        the_v.kelolaToko().addActionListener(new kelolaToko_Listener());
    }

    private void SembunyikanImage() {
        the_v.setImage().setVisible(false);
        the_v.setName().setVisible(false);
    }

    private void setEvaluasi(String status) {
        if (status.equalsIgnoreCase("on")) {
            the_v.getDropDown_Verifikasi().setVisible(true);
            the_v.setVerifikasiGaji().setVisible(true);
            the_v.setUbahGaji().setVisible(true);
            the_v.setGrafik().setVisible(true);
        } else if (status.equalsIgnoreCase("off")) {
            sembunyikanFitur_Evaluasi();
        }
    }

    private void setDistribusi(String status) {
        if (status.equalsIgnoreCase("on")) {
            the_v.getDropDown_distributor().setVisible(true);
            the_v.setAddToko_btn().setVisible(true);
            the_v.setPrediksi_btn().setVisible(true);
            the_v.setListDIstribusi_btn().setVisible(true);
        } else if (status.equalsIgnoreCase("off")) {
            SembunyikanFiturDIstribusi();
        }
    }

    private void sembunyikanFitur_Evaluasi() {
        the_v.getDropDown_Verifikasi().setVisible(false);
        the_v.setVerifikasiGaji().setVisible(false);
        the_v.setUbahGaji().setVisible(false);
        the_v.setGrafik().setVisible(false);
    }

    private void SembunyikanFiturDIstribusi() {
        the_v.getDropDown_distributor().setVisible(false);
        the_v.setAddToko_btn().setVisible(false);
        the_v.setPrediksi_btn().setVisible(false);
        the_v.setListDIstribusi_btn().setVisible(false);
    }

    private class profileListner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusButton_Profile == true) {
                the_v.getPop_Profile().setVisible(true);
                the_v.getPop_Nama().setVisible(true);
                the_v.setImage().setVisible(true);
                the_v.setButtonKeluar().setVisible(true);
                the_v.NamaDirektur(username);
                SembunyikanFiturDIstribusi();
                statusButton_Profile = false;
            } else {
                the_v.getPop_Profile().setVisible(false);
                the_v.getPop_Nama().setVisible(false);
                the_v.setImage().setVisible(false);
                the_v.setButtonKeluar().setVisible(false);
                statusButton_Profile = true;
            }

        }

    }

    private class logoutListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            JOptionPane pane = new JOptionPane("Anda Yakin akan keluar");
            Object[] options = new String[]{"YES", "NO"};
            soundTombol();
            pane.setOptions(options);
            JDialog dialog = pane.createDialog(new JFrame(), "Message");
            dialog.show();
            Object obj = pane.getValue();
            if (obj.equals("YES")) {
                soundTombol();
                new c_Beranda();
                the_v.dispose();
            } else {
                the_v.getPop_Profile().setVisible(false);
                SembunyikanImage();
            }
        }
    }

    private class showDropDown_Distribusi implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            soundTombol();
            if (statusButton_Distributor) {
                the_v.getDropDown_distributor().setVisible(true);
                the_v.setAddToko_btn().setVisible(true);
                the_v.setPrediksi_btn().setVisible(true);
                the_v.setListDIstribusi_btn().setVisible(true);
                statusButton_Distributor = false;
            } else {
                the_v.getDropDown_distributor().setVisible(false);
                the_v.setAddToko_btn().setVisible(false);
                the_v.setPrediksi_btn().setVisible(false);
                the_v.setListDIstribusi_btn().setVisible(false);
                statusButton_Distributor = true;
            }
        }
    }

    private class showDropDown_Evaluasi implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {

            soundTombol();
            if (statusButton_Evaluasi) {
                the_v.getDropDown_Verifikasi().setVisible(true);
                the_v.setVerifikasiGaji().setVisible(true);
                the_v.setUbahGaji().setVisible(true);
                the_v.setGrafik().setVisible(true);
                statusButton_Evaluasi = false;
            } else {
                sembunyikanFitur_Evaluasi();
                statusButton_Evaluasi = true;
            }
        }
    }

    private class tambahToko_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Toko(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Direktur.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }

    private class prediksiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                new c_Distribusi_Laporan(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Direktur.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }

    }
    private class Validsi_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                new c_validasiGaji(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Direktur.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }
        
    }
    private class Gaji_HRD_Listener implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                new c_perbaruiGaji_HRD(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Direktur.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }
        
    }
    
    private class Grafik_Listener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                new c_grafikDIstribusi(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Direktur.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }
        
    }
    private class kelolaToko_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                new c_kelola_Toko(username);
            } catch (SQLException ex) {
                Logger.getLogger(c_Direktur.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_v.dispose();
        }
        
    }
}
