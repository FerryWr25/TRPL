/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import View.Sifings_Login;
import View.HRD_Home;

public class c_About extends CLass_Musik.Musik{

    private int Ambil_Level;
    private View.Aabout_Team the_V;

    public c_About() {
        int Ambil_Dalam = 0;
        this.Ambil_Level = Ambil_Dalam;
        the_V = new View.Aabout_Team();
        the_V.setVisible(true);
        the_V.tombolBack_Home(new backHome_Listener());
    }

    private class backHome_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Beranda();
           the_V.dispose();
        }

    }
}
