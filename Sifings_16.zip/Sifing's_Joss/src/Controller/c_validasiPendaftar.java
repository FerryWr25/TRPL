package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class c_validasiPendaftar extends CLass_Musik.Musik{

    private View.Validasi_Pendaftar the_V;
    private View.Sifings_Login the_V2;
    private Model.Pegawai the_M;
    private boolean statusModal = true;
    private String username;

    public c_validasiPendaftar(String username) throws SQLException {
        the_V = new View.Validasi_Pendaftar();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Pegawai();
        the_V.setVisible(true);
        the_V.setTablePendatar(the_M.getData_Pendaftar_Validasi());
        the_V.setModal().setVisible(false);
        the_V.setInputNilai().setVisible(false);
        the_V.setCancel().setVisible(false);
        the_V.setSubmit().setVisible(false);
        the_V.tombolPenilaian(new updateListener());
        the_V.Penilaian(new Modal_Pop_Listner());
        the_V.tombolCancel(new cancelListener());
        the_V.backHome(new BackHome_Listener());
    }

    private class Modal_Pop_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusModal == true) {
                if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                    the_V.tampilPesan("Silahkan pilih baris tabel dahulu");
                } else {
                    the_V.setModal().setVisible(true);
                    the_V.setInputNilai().setVisible(true);
                    the_V.setSubmit().setVisible(true);
                    the_V.setCancel().setVisible(true);
                    statusModal = false;
                }
            } else {
                the_V.setModal().setVisible(false);
                the_V.setInputNilai().setVisible(false);
                the_V.setCancel().setVisible(false);
                the_V.setSubmit().setVisible(false);
                the_V.setNilai("");
                the_V.editTable().setEnabled(true);
                statusModal = true;
            }

        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                the_V.tampilPesan("Silahkan pilih tabel terlebih dahulu");
            } else {
                if (the_V.getNilai().isEmpty()) {
                    the_V.tampilPesan("Silahkan Masukkan penilai anda:");
                } else if (the_M.insertDataNilai(the_V.getNilai_Pendaftar(), the_V.GetTable())) {
                    soundTombol();
                    the_V.tampilPesan("Sukses Input Nilai");
                    the_V.setNilai("");
                    the_V.setModal().setVisible(false);
                    the_V.setInputNilai().setVisible(false);
                    the_V.setSubmit().setVisible(false);
                    the_V.setCancel().setVisible(false);
                    statusModal = false;
                } else {
                    the_V.tampilPesan("GAGAL");
                    the_V.editTable().setEnabled(true);
                    statusModal = true;
                }
            }
        }

    }

    private class cancelListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setInputNilai().setVisible(false);
            the_V.setSubmit().setVisible(false);
            the_V.setModal().setVisible(false);
            the_V.setCancel().setVisible(false);
        }

    }
    private class BackHome_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_HRD(username);
            the_V.dispose();
        }
        
    }

}
