/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_Pengumuman extends CLass_Musik.Musik {

    private View.Pendaftar_Lolos the_V;
    private Model.Pegawai the_M;
    private View.Sifings_Login the_V2;
    private String username;

    public c_Pengumuman(String username) throws SQLException {
        the_V = new View.Pendaftar_Lolos();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Pegawai();
        the_V.setVisible(true);
        the_V.buttonBatas(new Tampilkan_Listner());
        the_V.buttonShowAll(new showAll_Listener());
        the_V.setTablePendatar_lolos(the_M.getDataPendaftar_TOTAL());
        the_V.buttonBackHome(new backHome_Listener());
        the_V.buttonUmumkan(new umumkanLIstener());

        //random password
        Long.toHexString(Double.doubleToLongBits(Math.random()));
        UUID.randomUUID().toString();
        System.out.println(UUID.randomUUID());

    }

    private class Tampilkan_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                the_V.setTablePendatar_lolos(the_M.getDataPendaftar_Lolos(the_V.getBatas()));
                the_V.setFieldBatas("");
            } catch (SQLException ex) {
                Logger.getLogger(c_Pengumuman.class.getName()).log(Level.SEVERE, null, ex);
            }
            System.out.println(the_V.getBatas().length());
        }

    }

    private class backHome_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_HRD(username);
            the_V.dispose();
        }

    }

    private class umumkanLIstener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {

            for (int i = 0; i < Integer.parseInt(the_V.getBatas()); i++) {
                System.out.println(Integer.parseInt(the_V.getBatas()));
                try {
                    if (the_M.insertaryawanBaru("Null", the_M.getNamaLOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                            the_M.getUsernameLOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), String.valueOf(UUID.randomUUID()),
                            the_M.getJenisKelamin_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), the_M.getJenisAgama_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                            "3", the_M.getTTL_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), the_M.getAlamat_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                            the_M.getKota_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), "'-'", the_M.getNo_Telp_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                            "'-'", "Pegawai Tetap", "0", "2000000" ,"Terverifikasi")) {
                        try {
                            System.out.println(the_M.insertaryawanBaru("Null", the_M.getNamaLOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                                    the_M.getUsernameLOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), String.valueOf(UUID.randomUUID()),
                                    the_M.getJenisKelamin_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), the_M.getJenisAgama_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                                    "3", the_M.getTTL_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), the_M.getAlamat_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                                    the_M.getKota_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]), "'-'", the_M.getNo_Telp_LOLOS(the_M.getID_LOLOS(the_V.getBatas())[i]),
                                    "'-'", "Pegawai Tetap", "0", "2000000","Terverifikasi"));
                            the_M.Hapus_DataPgwai_Lama(the_M.getID_LOLOS(the_V.getBatas())[i]);
                        } catch (SQLException ex) {
                            Logger.getLogger(c_Pengumuman.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        the_V.tampilPesan("karyawan berhasil dimasukkan");
                    } else {
                        the_V.tampilPesan("Data Gagal Dimasukkan");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(c_Pengumuman.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            try {
                the_V.setTablePendatar_lolos(the_M.getDataPendaftar_TOTAL());
            } catch (SQLException ex) {
                Logger.getLogger(c_Pengumuman.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private class showAll_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                the_V.setTablePendatar_lolos(the_M.getDataPendaftar_TOTAL());
            } catch (SQLException ex) {
                Logger.getLogger(c_Pengumuman.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
