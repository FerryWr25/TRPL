/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_settingAkun extends CLass_Musik.Musik {

    private View.SettingAkun_Baru the_V;
    private View.Sifings_Login the_V2;
    private Model.Pegawai the_M;
    private String username;
    private boolean statusModal = true;

    public c_settingAkun(String username) throws SQLException {
        the_V = new View.SettingAkun_Baru();
        the_V2 = new View.Sifings_Login();
        the_M = new Model.Pegawai();
        this.username = username;
        the_V.setVisible(true);
        the_V.setModal().setVisible(false);
        the_V.setInputPassword().setVisible(false);
        the_V.setCancel().setVisible(false);
        the_V.setSubmit().setVisible(false);
        the_V.editTable().setEnabled(true);
        the_V.setTableKaryawanNya(the_M.getDataaryawanBaru_Seting());
        the_V.buttonGanti_Password(new Modal_Pop_Listner());
        the_V.setCancel().addActionListener(new cancelistener());
        the_V.setSubmit().addActionListener(new updateListener());
        the_V.backHome(new backHome_Listner());
    }

    private class Modal_Pop_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusModal == true) {
                if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                    the_V.tampilPesan("Silahkan pilih baris tabel dahulu");
                } else {
                    the_V.setModal().setVisible(true);
                    the_V.setInputPassword().setVisible(true);
                    the_V.setSubmit().setVisible(true);
                    the_V.setCancel().setVisible(true);
                    statusModal = false;
                }
            } else {
                the_V.setModal().setVisible(false);
                the_V.setInputPassword().setVisible(false);
                the_V.setCancel().setVisible(false);
                the_V.setSubmit().setVisible(false);
                the_V.editTable().setEnabled(true);
                statusModal = true;
            }

        }

    }

    private class cancelistener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setModal().setVisible(false);
            the_V.setInputPassword().setVisible(false);
            the_V.setCancel().setVisible(false);
            the_V.setSubmit().setVisible(false);
            statusModal = true;
            the_V.editTable().setEnabled(true);
        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                the_V.tampilPesan("Silahkan pilih tabel terlebih dahulu");
            } else {
                if (the_V.getPassword().isEmpty()) {
                    the_V.tampilPesan("Silahkan Masukkan password dulu:");
                } else if (the_V.getPassword().equalsIgnoreCase(" ")) {
                    the_V.tampilPesan("Password Tidak boleh diawali spasi :");
                    the_V.setPaswordNya("");

                } else if (the_V.getPassword().equalsIgnoreCase("  ")) {
                    the_V.tampilPesan("Password Tidak boleh diawali spasi :");
                    the_V.setPaswordNya("");

                } else if (the_M.insertPassword_Sales(the_V.getPassword(), the_V.GetTable())) {
                    soundTombol();
                    the_V.tampilPesan("Sukses Input Password baru");
                    the_V.setPaswordNya("");
                    the_V.setModal().setVisible(false);
                    the_V.setInputPassword().setVisible(false);
                    the_V.setSubmit().setVisible(false);
                    the_V.setCancel().setVisible(false);
                    statusModal = true;
                    try {
                        the_V.setTableKaryawanNya(the_M.getDataaryawanBaru_Seting());
                    } catch (SQLException ex) {
                        Logger.getLogger(c_ValidasiDIstribusi.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    statusModal = true;
                } else {
                    the_V.tampilPesan("GAGAL");
                    the_V.editTable().setEnabled(true);
                    statusModal = true;
                }
            }
        }

    }

    private class backHome_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_HRD(username);
            the_V.dispose();
        }

    }

}
