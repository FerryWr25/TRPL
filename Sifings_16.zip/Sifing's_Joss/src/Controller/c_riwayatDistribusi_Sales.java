/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_riwayatDistribusi_Sales extends CLass_Musik.Musik {

    private View.Riwayat_GagalTarget the_V;
    private View.Sifings_Login the_V2;
    private Model.Distribusi the_M;
    private String username;

    public c_riwayatDistribusi_Sales(String username) throws SQLException {
        the_V = new View.Riwayat_GagalTarget();
        the_V2 = new View.Sifings_Login();
        the_M = new Model.Distribusi();
        this.username = username;
        the_V.setVisible(true);
        the_V.setTotalDistribusi(the_M.getTotalDistribusi(the_M.getIdKaryawan(username)));
        the_V.setJumlahToko(the_M.getTotalTotalToko(the_M.getIdKaryawan(username)));
        the_V.setBeban(the_M.getBEban_Periode(the_M.getPeriode()));
        the_V.setTableRiwayat(the_M.getRiwayat_GagaLDistribusi(the_M.getIdKaryawan(username)));
        the_V.tombolCari(new cariRiwayat_Distribusi());
        the_V.showAll(new showAll_Listener());
        the_V.tombolButtonHOme(new backHome_listener());

    }

    private class cariRiwayat_Distribusi implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                the_V.setTableRiwayat(the_M.getRiwayat_Pencarian(the_V.setPencarian(), the_M.getIdKaryawan(username)));
            } catch (SQLException ex) {
                Logger.getLogger(c_riwayatDistribusi_Sales.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_V.setFieldCari("");
        }

    }

    private class showAll_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            try {
                the_V.setTableRiwayat(the_M.getRiwayat_GagaLDistribusi(the_M.getIdKaryawan(username)));
            } catch (SQLException ex) {
                Logger.getLogger(c_riwayatDistribusi_Sales.class.getName()).log(Level.SEVERE, null, ex);
            }
            the_V.setFieldCari("");
        }

    }

    private class backHome_listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Sales(username);
            the_V.dispose();
        }

    }

}
