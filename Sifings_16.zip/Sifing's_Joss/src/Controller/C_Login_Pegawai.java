/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Rini
 */
public class C_Login_Pegawai extends CLass_Musik.Musik {

    private View.Sifings_Login the_V;
    private Model.Pegawai the_M;
    private String Username;
    public int LevelNya;

    public C_Login_Pegawai() throws SQLException {
        int LevelDalam = 0;
        this.LevelNya = LevelDalam;
        the_V = new View.Sifings_Login();
        the_M = new Model.Pegawai();
        the_V.tombolLogin(new loginListener());
        this.the_V.usernameOnFocus(new usernameListener());
        this.the_V.passwordOnFocus(new passwordListener());
        this.the_V.tombolTampilkan_Pass(new Tampilkam_PassListener());
        the_V.tombolHome(new homeListener());
        the_V.setVisible(true);
    }

    private class Tampilkam_PassListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            soundTombol();
            if (the_V.chek_List_Password()) {
                the_V.setVisiblePass((char) 0);
            } else {
                the_V.setVisiblePass('*');
            }
        }

    }

    private class loginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            soundTombol();
            if (the_V.getUsername().isEmpty() && the_V.getPassword().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Silahkan masukkan username "
                        + "dan password Anda.", "Informasi Untuk anda", JOptionPane.INFORMATION_MESSAGE);
                soundTombol();
            } else if (the_V.getUsername().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Silahkan masukkan username anda",
                        "Informasi Untuk anda", JOptionPane.INFORMATION_MESSAGE);
                soundTombol();
            } else if (the_V.getPassword().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Silahkan masukkan password anda",
                        "Informasi Untuk anda", JOptionPane.INFORMATION_MESSAGE);
                soundTombol();
            } else {
                try {
                    if (the_M.getPegawai(the_V.getUsername(), the_V.getPassword())) {
                        if (the_M.getJabatan().equalsIgnoreCase("1")) {
                            System.out.println(the_M.getJabatan());
                            LevelNya = 1;
                            new c_Direktur(the_V.getUsername());
                            the_V.dispose();
                        } else if (the_M.getJabatan().equalsIgnoreCase("3")) {
                            LevelNya = 3;
                            new c_Sales(the_V.getUsername());
                            the_V.dispose();
                        } else if (the_M.getJabatan().equalsIgnoreCase("2")) {
                            LevelNya = 2;
                            new c_HRD(the_V.getUsername());
                            the_V.dispose();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Anda Tidak terdaftar",
                                "Informasi Untuk anda", JOptionPane.INFORMATION_MESSAGE);
                        the_V.setusername("");
                        the_V.setpassword("");
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(C_Login_Pegawai.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    private class usernameListener implements FocusListener {

        @Override
        public void focusGained(FocusEvent e) {
            if (the_V.getUsername().equalsIgnoreCase("Your Username")) {
                the_V.setUsername("");
            }
        }

        @Override
        public void focusLost(FocusEvent e) {
            if (the_V.getUsername().isEmpty()) {
                the_V.setUsername("Your Username");
            }
        }

    }

    private class passwordListener implements FocusListener {

        @Override
        public void focusGained(FocusEvent e) {
            if (the_V.getPassword().equalsIgnoreCase("Your Password")) {
                the_V.setPassword("");
            }
        }

        @Override
        public void focusLost(FocusEvent e) {
            if (the_V.getPassword().isEmpty()) {
                the_V.setPassword("Your Password");
            }
        }

    }

    private class homeListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_Beranda();
            the_V.dispose();
        }

    }

}
