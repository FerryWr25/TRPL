/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class c_grafikDIstribusi {

    private View.Grafik_Distribusi the_V;
    private View.Sifings_Login the_V2;
    private Model.Distribusi the_M;
    private String username;
    private XYSeriesCollection dataset = new XYSeriesCollection();

    private XYSeries seriesPD = new XYSeries(" Prediksi Distribusi  |");
    private XYSeries seriesPB = new XYSeries(" Prediksi Beban  |");

    private XYSeries series = new XYSeries(" Distribusi  |");
    private XYSeries seriesSemen = new XYSeries(" Semen  |");
    private XYSeries seriesMInimal_Distribusi = new XYSeries(" Beban Distribusi");
    private int batas, hasilPrediksi_jml, sisaSemenNya;

    public c_grafikDIstribusi(String username) throws SQLException {
        the_V = new View.Grafik_Distribusi();
        the_V2 = new View.Sifings_Login();
        the_M = new Model.Distribusi();
        batas = Integer.parseInt(the_M.getPeriode_Angka());
        JalankanMetodeNya_distribusi();
        the_V.chart(createDataset(the_M.getID_Distribusi(), the_M.getDistribusi_Grafik()));
        the_V.chart(createDatasetSemen(the_M.getID_Distribusi(), the_M.getSisa_Semen()));
        the_V.chart(createDatasetMinimal(the_M.getID_Distribusi(), the_M.getMInimal()));
        the_V.reset();
        the_V.setVisible(true);
        this.username = username;
        the_V.backHome(new backHOme_Listener());
    }

    private void JalankanMetodeNya_distribusi() throws SQLException {
        int p1, p2, p3, p4, rata1, rata2, rata1dan2;
        int isi[] = new int[batas];
        if (batas <= 4) {
            for (int i = isi.length - 1; i >= 0; i--) {
                isi[i] = Integer.parseInt(the_M.getDATA_Periode(i + 1));
                System.out.println(isi[i]);
            }
            System.out.println("/////////////");
            p1 = isi[3];
            p2 = isi[2];
            rata1 = (p1 + p2) / 2;
            p3 = isi[1];
            p4 = isi[0];
            rata2 = (p3 + p4) / 2;
            rata1dan2 = (rata1 + rata2) / 2;
            System.out.println(rata1dan2);

        } else {
            for (int i = isi.length - 1; i >= 0; i--) {
                isi[i] = Integer.parseInt(the_M.getDATA_Periode(i + 1));
                System.out.println(isi[i]);
            }
            System.out.println("/////////////");
            p1 = isi[isi.length - 1];
            p2 = isi[isi.length - 2];
            rata1 = (p1 + p2) / 2;
            p3 = isi[isi.length - 3];
            p4 = isi[isi.length - 4];
            rata2 = (p3 + p4) / 2;
            rata1dan2 = (rata1 + rata2) / 2;
            hasilPrediksi_jml = rata1dan2;
            System.out.println(rata1dan2);
            int persediaan = Integer.parseInt(the_M.getSisaSemen());

            //SISA SEMEN
            int totalPengadaan = Integer.parseInt(the_M.getTotalPengadaan());
            int totalKirim = Integer.parseInt(the_M.getTotalPengiriman());
            sisaSemenNya = totalPengadaan - totalKirim;

            int prediksi_FIX = (hasilPrediksi_jml - sisaSemenNya);
        }
    }

    public XYDataset createDataset(int Periode[], int jumlahDstribusi[]) throws SQLException {
        for (int i = 0; i < Periode.length; i++) {
            series.add(Periode[i], jumlahDstribusi[i]);
        }
        seriesPD.add(Periode[Periode.length - 1], jumlahDstribusi[jumlahDstribusi.length - 1]);
        seriesPD.add(Periode[Periode.length - 1] + 1, hasilPrediksi_jml);
        dataset.addSeries(series);
        dataset.addSeries(seriesPD);
        return dataset;
    }

    public XYDataset createDatasetSemen(int Periode[], int sisaSemen[]) {
        for (int i = 0; i < Periode.length; i++) {
            seriesSemen.add(Periode[i], sisaSemen[i]);
        }
        dataset.addSeries(seriesSemen);
        return dataset;
    }

    public XYDataset createDatasetMinimal(int Periode[], int minimal[]) {
        for (int i = 0; i < Periode.length; i++) {
            seriesMInimal_Distribusi.add(Periode[i], minimal[i]);
        }
        dataset.addSeries(seriesMInimal_Distribusi);
        return dataset;
    }

    private class backHOme_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_Direktur(username);
            the_V.dispose();
        }

    }

}
