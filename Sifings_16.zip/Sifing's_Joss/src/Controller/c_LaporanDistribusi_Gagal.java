/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_LaporanDistribusi_Gagal extends CLass_Musik.Musik {

    private View.DIstribusi_Gagal the_v;
    private Model.Distribusi the_M;
    private View.Sifings_Login the_V2;
    private String username;
    private boolean statusModal = true;

    public c_LaporanDistribusi_Gagal(String username) throws SQLException {
        this.username = username;
        the_v = new View.DIstribusi_Gagal();
        the_M = new Model.Distribusi();
        the_v.setVisible(true);
        sembunyikanFiturModal();
        the_v.setTablePunisment(the_M.getKaryawan_GagaLDistribusi());
        the_v.tombolBack_Home(new backTo_Home());
        the_v.tombolAdd_Catatan(new showMOdalPenilaian_Listener());
        the_v.tombolCancel(new cancelListener());
        the_v.tombolSubmit_Catatan(new beriNilai_Listener() );
    }

    private void sembunyikanFiturModal() {
        the_v.setModal().setVisible(false);
        the_v.setInputNilai().setVisible(false);
        the_v.setSubmit().setVisible(false);
        the_v.setCancel().setVisible(false);
    }

    private void tampilkanFiturModal() {
        the_v.setModal().setVisible(true);
        the_v.setInputNilai().setVisible(true);
        the_v.setSubmit().setVisible(true);
        the_v.setCancel().setVisible(true);
    }

    private class cancelListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            sembunyikanFiturModal();
        }

    }

    private class backTo_Home implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_HRD(username);
            the_v.dispose();
        }
    }

    private class showMOdalPenilaian_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (statusModal == true) {
                if (the_v.getSelectedRow() == -1) {
                    the_v.tampilPesan("Silahkan pilih baris tabel dahulu");
                } else {
                    tampilkanFiturModal();
                    statusModal = false;
                }

            } else {
                sembunyikanFiturModal();
                statusModal = true;
            }
        }

    }

    private class beriNilai_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            try {
                if (the_M.insertCatatan(the_v.getCatatan(), the_v.GetTable())) {
                    the_v.tampilPesan("Pesan berhasil dimasukan");
                    the_v.setFieldCatatan("");
                    the_v.setTablePunisment(the_M.getKaryawan_GagaLDistribusi());
                    sembunyikanFiturModal();
                } else {
                    the_v.tampilPesan("Pesan gagal dimasukkan");
                }
            } catch (SQLException ex) {
                Logger.getLogger(c_LaporanDistribusi_Gagal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
}
