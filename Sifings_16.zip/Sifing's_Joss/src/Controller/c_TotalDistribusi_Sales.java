/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class c_TotalDistribusi_Sales extends CLass_Musik.Musik{

    private View.ViewDistribusi_Sales the_V;
    private Model.Distribusi the_M;
    private View.Sifings_Login the_V2;
    private String username;

    public c_TotalDistribusi_Sales(String username) throws SQLException {
        the_V = new View.ViewDistribusi_Sales();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Distribusi();
        the_V.setVisible(true);
        the_V.setTotalDistribusi(the_M.getTotalDistribusi_Sales(username));
        the_V.tombolButtonHOme(new backHomeLIstener());
        the_V.setCatatanMu(the_M.getCatatanku(username));
    }

    private class backHomeLIstener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Sales(username);
            the_V.dispose();
        }

    }

}
