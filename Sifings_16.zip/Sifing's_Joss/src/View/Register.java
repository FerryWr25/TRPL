/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import com.toedter.calendar.JCalendar;
import com.toedter.calendar.JDateChooser;
import datechooser.beans.DateChooserCombo;
import java.awt.Choice;
import java.awt.event.ActionListener;
import java.util.Locale;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Register extends javax.swing.JFrame {

    JDateChooser chooser = new JDateChooser();
    String Tanggal = chooser.getDateFormatString();
    public static String namaPendaftar;

    public Register() {
        initComponents();
        this.setLocationRelativeTo(this);
    }
    ///set kosong awal form
    public void setCOmboJengkeel(String text){
        combo_jengkel.setSelectedItem(text);
    }
    public void setCOmboAgama(String text){
        combo_agama.setSelectedItem(text);
    }
    public void setCOmboKeterbatasan(String text){
        combo_keterbatasan.setSelectedItem(text);
    }
    public void setCOmboKeahlian(String text){
        combo_keahlian.setSelectedItem(text);
    }
    public String getNamaPendaftar() {
        return filed_nama.getText();
    }
    public String getAlamat() {
        return filed_alamat.getText();
    }
    public String getJenisKelamin() {
        return (String) this.combo_jengkel.getSelectedItem();
    }
    public String getJenisAgama() {
        return (String) this.combo_agama.getSelectedItem();
    }

    public JLabel getModal_Print() {
        return modal_print;
    }
    public JLabel getWOrd() {
        return word_information;
    }
    //ngeset field form
    public void setNama (String text){
        this.filed_nama.setText(text);
    }
    public void setAlamat (String text){
        this.filed_alamat.setText(text);
    }
    public void setKota (String text){
        this.filed_nama.setText(text);
    }
    public void setAgama (String text){
        this.combo_agama.addItem(text);
    }
    public void setJenisKL (String text){
        this.combo_jengkel.addItem(text);
    }
    public void setKeAhlian (String text){
        this.combo_keahlian.addItem(text);
    }
    public void setKeterbatasan (String text){
        this.combo_keterbatasan.addItem(text);
    }
    public void setAlasan (String text){
        this.textarea_pendaftar.setText(text);
    }
  
////////////////////
    public JTextField getNama_Set() {
        return filed_nama;
    }
    public JTextField getAlamat_Set() {
        return filed_alamat;
    }
    public JTextField setKota (){
        return filed_kota;
    }
    public String getKOta() {
        return filed_kota.getText();
    }
    public String getAlasan() {
        return textarea_pendaftar.getText();
    }
    public String getNomer_Telp() {
        return filed_notelp.getText();
    }
    public JButton getModal_Exit() {
        return keluarModal;
    }

    public JButton getModal_Download() {
        return tombolPrint;
    }
    public JComboBox getComboJenis_Kel() {
        return combo_jengkel;
    }
    public JComboBox getAgama_set() {
        return combo_agama;
    }
    public JComboBox getKeahian_set() {
        return combo_keahlian;
    }
    public DateChooserCombo getTanggal_set() {
        return jCalender;
    }
    public JComboBox getKeterbatasan_set() {
        return combo_keterbatasan;
    }

    
    public void setTombolButton_Submit (boolean enable){
        this.submitButton.setEnabled(enable);
    }
    public void setTombolButton_Cancel (boolean enable){
        this.cancelButton.setEnabled(enable);
    }
    public void setTombolButton_Home (boolean enable){
        this.tombolBack.setEnabled(enable);
    }


    public void setNomer_Telp(String text) {
        this.filed_notelp.setText(text);
    }


    public void tombolBack_Home(ActionListener action) {
        this.tombolBack.addActionListener(action);
    }

    public void tombolSubmit(ActionListener action) {
        this.submitButton.addActionListener(action);
    }

    public void tombolPrintKartu(ActionListener action) {
        this.tombolPrint.addActionListener(action);
    }

    public void tombolKeluarModal(ActionListener action) {
        this.keluarModal.addActionListener(action);
    }

    public void tombolCancel(ActionListener action) {
        this.cancelButton.addActionListener(action);
    }

    public void getAgama(String text) {
        this.combo_agama.addItem(text);
    }

    public void getJengkel(String text) {
        this.combo_jengkel.addItem(text);
    }

    public String[] getDataPendaftar() {
        String Data[] = new String[10];
        Data[0] = this.filed_nama.getText();
        Data[1] = (String) this.combo_jengkel.getSelectedItem();
        Data[2] = (String) this.combo_agama.getSelectedItem();
        Data[3] = this.jCalender.getText();
        Data[4] = this.filed_alamat.getText();
        Data[5] = this.filed_kota.getText();
        Data[6] = this.filed_notelp.getText();
        Data[7] = (String) this.combo_keahlian.getSelectedItem();
        Data[8] = (String) this.combo_keterbatasan.getSelectedItem();
        Data[9] = this.textarea_pendaftar.getText();
        return Data;
    }

    public void tampilPesan(String pesan) {
        JOptionPane.showMessageDialog(this, pesan);
    }

    public int tampilPeringatan(String pesan) {
        return JOptionPane.showConfirmDialog(this, pesan, null, JOptionPane.YES_NO_OPTION);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        word_information = new javax.swing.JLabel();
        keluarModal = new javax.swing.JButton();
        tombolPrint = new javax.swing.JButton();
        modal_print = new javax.swing.JLabel();
        cancelButton = new javax.swing.JButton();
        submitButton = new javax.swing.JButton();
        filed_notelp = new javax.swing.JTextField();
        filed_nama = new javax.swing.JTextField();
        filed_alamat = new javax.swing.JTextField();
        jCalender = new datechooser.beans.DateChooserCombo();
        filed_kota = new javax.swing.JTextField();
        combo_agama = new javax.swing.JComboBox();
        combo_jengkel = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        textarea_pendaftar = new javax.swing.JTextArea();
        combo_keterbatasan = new javax.swing.JComboBox();
        combo_keahlian = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        tombolBack = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        word_information.setFont(new java.awt.Font("Agency FB", 1, 14)); // NOI18N
        word_information.setForeground(new java.awt.Color(255, 255, 255));
        word_information.setText("Silahkan download kartu persetuan kerja diatas");
        getContentPane().add(word_information, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 470, 250, 30));

        keluarModal.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/tombolexitModalPrint.png"))); // NOI18N
        keluarModal.setBorderPainted(false);
        keluarModal.setContentAreaFilled(false);
        keluarModal.setFocusPainted(false);
        keluarModal.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/tombol(Roll)exitModalPrint.png"))); // NOI18N
        getContentPane().add(keluarModal, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 180, 70, 50));

        tombolPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/buttonPrint.png"))); // NOI18N
        tombolPrint.setBorderPainted(false);
        tombolPrint.setContentAreaFilled(false);
        tombolPrint.setFocusPainted(false);
        tombolPrint.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/buttonRollPrint.png"))); // NOI18N
        getContentPane().add(tombolPrint, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 420, 280, 50));

        modal_print.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/modalPrint.png"))); // NOI18N
        getContentPane().add(modal_print, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 200, 450, 330));

        cancelButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Reset.png"))); // NOI18N
        cancelButton.setBorderPainted(false);
        cancelButton.setContentAreaFilled(false);
        cancelButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cancelButton.setFocusable(false);
        cancelButton.setRequestFocusEnabled(false);
        cancelButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Reset 2.png"))); // NOI18N
        cancelButton.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(cancelButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1080, 280, 210, 70));

        submitButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Submit.png"))); // NOI18N
        submitButton.setBorderPainted(false);
        submitButton.setContentAreaFilled(false);
        submitButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        submitButton.setFocusable(false);
        submitButton.setRequestFocusEnabled(false);
        submitButton.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Submit 2.png"))); // NOI18N
        submitButton.setVerifyInputWhenFocusTarget(false);
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(submitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 190, 190, 70));
        getContentPane().add(filed_notelp, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 400, 270, 30));
        getContentPane().add(filed_nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 170, 270, 40));
        getContentPane().add(filed_alamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, 270, 30));

        jCalender.setCurrentView(new datechooser.view.appearance.AppearancesList("Dali",
            new datechooser.view.appearance.ViewAppearance("custom",
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(222, 222, 222),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(222, 222, 222),
                    new java.awt.Color(0, 0, 255),
                    true,
                    true,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(0, 0, 255),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(128, 128, 128),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.LabelPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(222, 222, 222),
                    new java.awt.Color(0, 0, 255),
                    false,
                    true,
                    new datechooser.view.appearance.swing.LabelPainter()),
                new datechooser.view.appearance.swing.SwingCellAppearance(new java.awt.Font("Dialog", java.awt.Font.PLAIN, 11),
                    new java.awt.Color(222, 222, 222),
                    new java.awt.Color(255, 0, 0),
                    false,
                    false,
                    new datechooser.view.appearance.swing.ButtonPainter()),
                (datechooser.view.BackRenderer)null,
                false,
                true)));
    getContentPane().add(jCalender, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 270, 270, 30));
    getContentPane().add(filed_kota, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 220, 200, 30));

    combo_agama.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " ", "Islam", "Kristen", "Hindu", "Budha", "Conghucu" }));
    combo_agama.setOpaque(false);
    getContentPane().add(combo_agama, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 360, 210, 30));

    combo_jengkel.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " ", "Laki-laki", "Perempuan" }));
    combo_jengkel.setOpaque(false);
    getContentPane().add(combo_jengkel, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 320, 210, 30));

    textarea_pendaftar.setColumns(20);
    textarea_pendaftar.setRows(5);
    jScrollPane1.setViewportView(textarea_pendaftar);

    getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 520, 270, -1));

    combo_keterbatasan.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " ", "Keterbatasan Public speaking", "Keterbatasan mengenai dampak tekanan kerja", "Belum bisa mengoprasikan komputer", "Tidak suka membaur sesama", "Kurang mampu dalam hal management waktu" }));
    getContentPane().add(combo_keterbatasan, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 480, 270, 30));

    combo_keahlian.setModel(new javax.swing.DefaultComboBoxModel(new String[] { " ", "Berbahasa inggris yang baik", "Menguasi bidang komputer", "Menguasai bidang marketing sales", "Mampu bekerja team dengan baik", "Pengalaman pernah kerja sebelumnya" }));
    getContentPane().add(combo_keahlian, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 440, 270, 30));

    jLabel14.setFont(new java.awt.Font("Arial", 0, 22)); // NOI18N
    jLabel14.setForeground(new java.awt.Color(255, 255, 255));
    jLabel14.setText("Kota");
    getContentPane().add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 220, 60, 30));

    tombolBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home.png"))); // NOI18N
    tombolBack.setBorderPainted(false);
    tombolBack.setContentAreaFilled(false);
    tombolBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
    tombolBack.setFocusPainted(false);
    tombolBack.setFocusable(false);
    tombolBack.setRequestFocusEnabled(false);
    tombolBack.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Button Home 2.png"))); // NOI18N
    tombolBack.setVerifyInputWhenFocusTarget(false);
    getContentPane().add(tombolBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(1090, 360, 190, 70));

    jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Form Register 2.png"))); // NOI18N
    getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1280, 720));

    pack();
    }// </editor-fold>//GEN-END:initComponents

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        this.namaPendaftar = filed_nama.getText();
    }//GEN-LAST:event_submitButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Register.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private javax.swing.JComboBox combo_agama;
    private javax.swing.JComboBox combo_jengkel;
    private javax.swing.JComboBox combo_keahlian;
    private javax.swing.JComboBox combo_keterbatasan;
    private javax.swing.JTextField filed_alamat;
    private javax.swing.JTextField filed_kota;
    private javax.swing.JTextField filed_nama;
    private javax.swing.JTextField filed_notelp;
    private datechooser.beans.DateChooserCombo jCalender;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton keluarModal;
    private javax.swing.JLabel modal_print;
    private javax.swing.JButton submitButton;
    private javax.swing.JTextArea textarea_pendaftar;
    private javax.swing.JButton tombolBack;
    private javax.swing.JButton tombolPrint;
    private javax.swing.JLabel word_information;
    // End of variables declaration//GEN-END:variables
}
