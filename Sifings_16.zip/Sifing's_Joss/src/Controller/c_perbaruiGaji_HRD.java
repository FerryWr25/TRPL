/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_perbaruiGaji_HRD extends CLass_Musik.Musik {

    private View.PerbaruiGaji_Hrd the_V;
    private Model.Pegawai the_M;
    private View.Sifings_Login the_V2;
    private String username;
    private boolean statusModal = true;

    public c_perbaruiGaji_HRD(String username) throws SQLException {
        the_V = new View.PerbaruiGaji_Hrd();
        the_V2 = new View.Sifings_Login();
        the_M = new Model.Pegawai();
        this.username = username;
        the_V.setVisible(true);
        the_V.setTableHRD(the_M.getDataaPerubahan_Gaji_HRD());
        the_V.perbaruiGaji(new Modal_Pop_Listner());
        the_V.setCancel().addActionListener(new cancelListener());
        the_V.setSubmit().addActionListener(new Perbarui_GajiListener());
        the_V.backHome(new backHome_Listner());
        the_V.setModal().setVisible(false);
        the_V.setInputGajii().setVisible(false);
        the_V.setCancel().setVisible(false);
        the_V.setSubmit().setVisible(false);
    }

    private class Modal_Pop_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusModal == true) {
                if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                    the_V.tampilPesan("Silahkan pilih baris tabel dahulu");
                } else {
                    the_V.setModal().setVisible(true);
                    the_V.setInputGajii().setVisible(true);
                    the_V.setSubmit().setVisible(true);
                    the_V.setCancel().setVisible(true);
                    statusModal = false;
                }
            } else {
                the_V.setModal().setVisible(false);
                the_V.setInputGajii().setVisible(false);
                the_V.setCancel().setVisible(false);
                the_V.setSubmit().setVisible(false);
                the_V.editTable().setEnabled(true);
                statusModal = true;
            }

        }

    }

    private class cancelListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setModal().setVisible(false);
            the_V.setInputGajii().setVisible(false);
            the_V.setCancel().setVisible(false);
            the_V.setSubmit().setVisible(false);
            the_V.editTable().setEnabled(true);
            statusModal = true;
        }

    }

    private class backHome_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Direktur(username);
            the_V.dispose();
        }

    }

    private class Perbarui_GajiListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (the_M.updateGaji_HRD(the_V.getGajiNya(), the_V.GetTable())) {
                the_V.tampilPesan("Gaji berhasil diperbarui");
                the_V.setInputGajii_Text("");
                the_V.setModal().setVisible(false);
                the_V.setInputGajii().setVisible(false);
                the_V.setCancel().setVisible(false);
                the_V.setSubmit().setVisible(false);
                the_V.editTable().setEnabled(true);
                statusModal = true;
                try {
                    the_V.setTableHRD(the_M.getDataaPerubahan_Gaji_HRD());
                } catch (SQLException ex) {
                    Logger.getLogger(c_Gaji.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                the_V.tampilPesan("Gaji GAGAL diperbarui");
            }
        }

    }
}
