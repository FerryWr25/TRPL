/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_Distribusi extends CLass_Musik.Musik {

    private View.Ditribusi_Sales the_V;
    private View.Sifings_Login the_v2;
    private Model.Distribusi the_M;
    boolean statusCalender = true;
    private String username;

    public c_Distribusi(String Username) throws SQLException {
        this.username = Username;
        the_V = new View.Ditribusi_Sales();
        the_v2 = new View.Sifings_Login();
        the_M = new Model.Distribusi();
        the_V.setVisible(true);
        the_V.tombolSubmit(new Distribusi_Listener());
        for (int i = 0; i < the_M.getNamaToko().length; i++) {
            the_V.setNAmaTOko().addItem(the_M.getNamaToko()[i]);
        }
        for (int i = 0; i < the_M.ID_BEban().length; i++) {
            the_V.noID().addItem(the_M.ID_BEban()[i]);
        }

        the_V.tombolBackHome(new home_Listener());
    }

    private class Distribusi_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            int cekquantity = 0;
            int cekquantityHuruf = 0;
            int cekHarga = 0;
            int cekHargaHuruf = 0;
            int cekDIscount = 0;
            int cekDIscountHuruf = 0;
            char huruf[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
            char everything[] = {'~', '`', '!', '@', '#', '#', '$', '%', '%', '^', '&', '*', '(', ')', '-', '_',
                '+', '=', '[', ']', ',', '{', '}', ':', ';', '"', '?', '/', '.', '>', '<', '|', ' '};
            char quantity[] = the_V.getQuantity().toCharArray();
            char harga[] = the_V.getHarga().toCharArray();
            char discount[] = the_V.getDiscount().toCharArray();

            for (int i = 0; i < quantity.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (quantity[i] == everything[j]) {
                        cekquantity++;
                    }
                }
            }
            for (int i = 0; i < quantity.length; i++) {
                for (int j = 0; j < huruf.length; j++) {
                    if (quantity[i] == huruf[j]) {
                        cekquantityHuruf++;
                    }
                }
            }
            for (int i = 0; i < harga.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (harga[i] == everything[j]) {
                        cekHarga++;
                    }
                }
            }
            for (int i = 0; i < harga.length; i++) {
                for (int j = 0; j < huruf.length; j++) {
                    if (harga[i] == huruf[j]) {
                        cekHargaHuruf++;
                    }
                }
            }
            for (int i = 0; i < discount.length; i++) {
                for (int j = 0; j < everything.length; j++) {
                    if (discount[i] == everything[j]) {
                        cekDIscount++;
                    }
                }
            }
            for (int i = 0; i < discount.length; i++) {
                for (int j = 0; j < huruf.length; j++) {
                    if (discount[i] == huruf[j]) {
                        cekDIscountHuruf++;
                    }
                }
            }

            if (the_V.getQuantity().isEmpty()) {
                the_V.tampilPesan("Quantitas tidak boleh kosong");
            } else if (the_V.getHarga().isEmpty()) {
                the_V.tampilPesan("Harga tidak boleh kosong");
            } else if (the_V.getDiscount().isEmpty()) {
                the_V.tampilPesan("isi discount dengan 0 jika tidak ada");
            } else if (the_V.getID().getSelectedItem().equals(" ")) {
                the_V.tampilPesan("No_Beban tidak boleh kosong");
            } else if (cekquantity > 0) {
                the_V.tampilPesan("Quantity Tidak valid, Silahkan isi dengan bilangan");
            } else if (cekquantityHuruf > 0) {
                the_V.tampilPesan("Quantity tidak boleh berisi huruf");
            } else if (cekHarga > 0) {
                the_V.tampilPesan("Harga Tidak valid, Silahkan isi dengan format rupiah tanpa titik [.]");
            } else if (cekHargaHuruf > 0) {
                the_V.tampilPesan("Harga tidak boleh berisi huruf");
            } else if (cekDIscount > 0) {
                the_V.tampilPesan("Discount Tidak valid, Silahkan isi dengan format bilangan");
            } else if (cekDIscountHuruf > 0) {
                the_V.tampilPesan("discount tidak boleh berisi huruf");
            } else {
                try {
                    if (the_M.insertDataDistribusi(the_M.getIDTOKO(the_V.AmbilNamaToko()),
                            the_M.getIDPegawai(username), the_V.getDataDistribusi())) {
                        the_V.tampilPesan("Data Distribusi Berhasil Dimasukkan");
                    } else {
                        the_V.tampilPesan("Data Distribusi Gagagl Dimasukkan");
                    }

                } catch (ParseException ex) {
                    Logger.getLogger(c_Distribusi.class.getName()).log(Level.SEVERE, null, ex);
                } catch (SQLException ex) {
                    Logger.getLogger(c_Distribusi.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    private class home_Listener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_Sales(username);
            the_V.dispose();
        }
    }
}
