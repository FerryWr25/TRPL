/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class c_Distribusi_HRD extends CLass_Musik.Musik{

    private View.Distribusi_HRD the_V;
    private Model.Pegawai the_M;
    private View.Sifings_Login the_V2;
    private String username;


    public c_Distribusi_HRD(String username) throws SQLException {
        the_V = new View.Distribusi_HRD();
        the_V2 = new View.Sifings_Login();
        this.username = username;
        the_M = new Model.Pegawai();
        the_V.setVisible(true);
        the_V.setTableDistribusi(the_M.getData_Distribusi());
        the_V.tombolBack_Home(new backHome_LIstner());
    }

    private class backHome_LIstner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            new c_HRD(username);
            the_V.dispose();
        }

    }

}
