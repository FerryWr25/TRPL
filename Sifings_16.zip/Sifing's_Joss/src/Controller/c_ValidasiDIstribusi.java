/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class c_ValidasiDIstribusi extends CLass_Musik.Musik {

    private View.Validasi_Distirbusi the_V;
    private Model.Distribusi the_M;
    private View.Sifings_Login the_V2;
    private String username;
    private boolean statusModal = true;

    public c_ValidasiDIstribusi(String username) throws SQLException {
        the_V = new View.Validasi_Distirbusi();
        the_V2 = new View.Sifings_Login();
        the_M = new Model.Distribusi();
        this.username = username;
        the_V.setVisible(true);
        the_V.buttonValidasi(new Modal_Pop_Listner());
        the_V.setModal().setVisible(false);
        the_V.setInputValidasi().setVisible(false);
        the_V.setCancel().setVisible(false);
        the_V.setSubmit().setVisible(false);
        the_V.setTableDistibusiNya(the_M.getDistibusi_BelumVRFSI());
        the_V.setSubmit().addActionListener(new updateListener());
        the_V.backHome(new backHome_Listner());
        the_V.cancel().addActionListener(new cancelListener());
    }

    private class cancelListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            the_V.setModal().setVisible(false);
            the_V.setInputValidasi().setVisible(false);
            the_V.setCancel().setVisible(false);
            the_V.setSubmit().setVisible(false);
            the_V.editTable().setEnabled(true);
            statusModal = true;
        }

    }

    private class Modal_Pop_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            soundTombol();
            if (statusModal == true) {
                if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                    the_V.tampilPesan("Silahkan pilih baris tabel dahulu");
                } else {
                    the_V.setModal().setVisible(true);
                    the_V.setInputValidasi().setVisible(true);
                    the_V.setSubmit().setVisible(true);
                    the_V.setCancel().setVisible(true);
                    statusModal = false;
                }
            } else {
                the_V.setModal().setVisible(false);
                the_V.setInputValidasi().setVisible(false);
                the_V.setCancel().setVisible(false);
                the_V.setSubmit().setVisible(false);
                the_V.editTable().setEnabled(true);
                statusModal = true;
            }

        }

    }

    private class updateListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if (the_V.getSelectedRow() == -1) { // jika tabel belum dipilih
                the_V.tampilPesan("Silahkan pilih tabel terlebih dahulu");
            } else {
                if (the_V.getValidasi().isEmpty()) {
                    the_V.tampilPesan("Silahkan Masukkan penilai anda:");
                } else if (the_V.getValidasi().equalsIgnoreCase(" ")) {
                    the_V.tampilPesan("Silahkan Masukkan penilai anda:");
                } else if (the_M.insertDataValidasi(the_V.getValidasi(), the_V.GetTable())) {
                    soundTombol();
                    the_V.tampilPesan("Sukses Input Nilai");
                    the_V.setModal().setVisible(false);
                    the_V.setInputValidasi().setVisible(false);
                    the_V.setSubmit().setVisible(false);
                    the_V.setCancel().setVisible(false);
                    try {
                        the_V.setTableDistibusiNya(the_M.getDistibusi_BelumVRFSI());
                    } catch (SQLException ex) {
                        Logger.getLogger(c_ValidasiDIstribusi.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    statusModal = false;
                } else {
                    the_V.tampilPesan("GAGAL");
                    the_V.editTable().setEnabled(true);
                    statusModal = true;
                }
            }
        }

    }

    private class backHome_Listner implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            new c_HRD(username);
            the_V.dispose();
        }

    }
}
